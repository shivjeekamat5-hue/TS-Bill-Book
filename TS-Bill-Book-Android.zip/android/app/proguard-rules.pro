# Keep JavaScript interfaces so they are not renamed or removed during minification
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# Keep the WebAppInterface and MainActivity classes intact
-keep class com.tsbillbook.app.WebAppInterface { *; }
-keep class com.tsbillbook.app.MainActivity { *; }
