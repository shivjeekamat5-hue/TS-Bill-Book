package com.tsbillbook.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import android.view.View
import android.webkit.*
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    private val TAG = "MainActivity"
    private lateinit var webView: WebView
    
    // File Chooser for camera scan & receipt uploads
    private var fileUploadCallback: ValueCallback<Array<Uri>>? = null
    private var cameraPhotoPath: String? = null

    // Launchers for modern Activity Results
    private val fileChooserLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val dataIntent = result.data
            var results: Array<Uri>? = null

            // Check if photo was captured via camera
            if (dataIntent == null || dataIntent.data == null) {
                cameraPhotoPath?.let { path ->
                    val file = File(path)
                    if (file.exists() && file.length() > 0) {
                        results = arrayOf(Uri.fromFile(file))
                    }
                }
            } else {
                val dataString = dataIntent.dataString
                if (dataString != null) {
                    results = arrayOf(Uri.parse(dataString))
                }
            }
            
            fileUploadCallback?.onReceiveValue(results)
        } else {
            fileUploadCallback?.onReceiveValue(null)
        }
        fileUploadCallback = null
    }

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            Toast.makeText(this, "Permission granted", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Camera permission is required for AI scans.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        // Install Native Splash Screen
        installSplashScreen()
        
        super.onCreate(savedInstanceState)
        
        // Setup WebView
        webView = WebView(this)
        setContentView(webView)

        configureWebViewSettings()
        setupWebViewClients()
        setupOnBackPressed()

        // Request runtime camera permission if needed
        checkAndRequestCameraPermission()

        // Load application - Prioritize local assets. Falls back to Cloud pre-production URL.
        val localUrl = "file:///android_asset/index.html"
        val fallbackCloudUrl = "https://ais-pre-adx675mkikk4iby32obsqt-474925021613.asia-southeast1.run.app"
        
        webView.loadUrl(fallbackCloudUrl)
    }

    private fun configureWebViewSettings() {
        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true // Required for firebase storage & user credentials
        settings.databaseEnabled = true
        settings.allowFileAccess = true
        settings.allowContentAccess = true
        settings.loadWithOverviewMode = true
        settings.useWideViewPort = true
        settings.cacheMode = WebSettings.LOAD_DEFAULT
        
        // Enable Mixed Content for secure requests loading any remote assets/API calls
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE

        // Add the Native-to-JS bridge
        webView.addJavascriptInterface(WebAppInterface(this), "AndroidBridge")
        
        // Performance configurations
        webView.scrollBarStyle = View.SCROLLBARS_INSIDE_OVERLAY
    }

    private fun setupWebViewClients() {
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url ?: return false
                val urlString = url.toString()

                // Intercept deep links (WhatsApp, UPI Payments, Phone, Email)
                if (urlString.startsWith("tel:") || 
                    urlString.startsWith("mailto:") || 
                    urlString.startsWith("upi:") || 
                    urlString.startsWith("whatsapp:") ||
                    urlString.contains("wa.me")
                ) {
                    try {
                        val intent = Intent(Intent.ACTION_VIEW, url)
                        startActivity(intent)
                        return true
                    } catch (e: Exception) {
                        Log.e(TAG, "Failed to launch intent for: $urlString", e)
                        Toast.makeText(this@MainActivity, "No compatible app found to handle request", Toast.LENGTH_SHORT).show()
                        return true
                    }
                }
                
                // Allow standard HTTP/HTTPS links to load internally inside the WebView
                return false
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                super.onReceivedError(view, request, error)
                if (request?.isForMainFrame == true) {
                    Log.e(TAG, "WebView error loading page: ${error?.description}")
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            // Handle native Javascript Alerts gracefully if triggered
            override fun onJsAlert(
                view: WebView?,
                url: String?,
                message: String?,
                result: JsResult?
            ): Boolean {
                Toast.makeText(this@MainActivity, message, Toast.LENGTH_SHORT).show()
                result?.confirm()
                return true
            }

            // Handle Camera Scan & File Upload integration (critical for AI SCAN receipt capture!)
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                if (fileUploadCallback != null) {
                    fileUploadCallback?.onReceiveValue(null)
                }
                fileUploadCallback = filePathCallback

                // Create intent for image capture via Camera
                val takePictureIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                if (takePictureIntent.resolveActivity(packageManager) != null) {
                    var photoFile: File? = null
                    try {
                        photoFile = createTempImageFile()
                    } catch (ex: IOException) {
                        Log.e(TAG, "Unable to create Image File", ex)
                    }

                    if (photoFile != null) {
                        val photoURI = FileProvider.getUriForFile(
                            this@MainActivity,
                            "com.tsbillbook.app.fileprovider",
                            photoFile
                        )
                        cameraPhotoPath = photoFile.absolutePath
                        takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
                    }
                }

                // Intent for selecting documents / image files from gallery
                val contentSelectionIntent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "image/*"
                }

                val intentArray: Array<Intent> = if (takePictureIntent.resolveActivity(packageManager) != null) {
                    arrayOf(takePictureIntent)
                } else {
                    emptyArray()
                }

                val chooserIntent = Intent(Intent.ACTION_CHOOSER).apply {
                    putExtra(Intent.EXTRA_INTENT, contentSelectionIntent)
                    putExtra(Intent.EXTRA_TITLE, "Select Receipt Image")
                    putExtra(Intent.EXTRA_INITIAL_INTENTS, intentArray)
                }

                fileChooserLauncher.launch(chooserIntent)
                return true
            }
        }
    }

    private fun setupOnBackPressed() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack() // Navigate web history
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed() // Exit App
                }
            }
        })
    }

    private fun checkAndRequestCameraPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    @Throws(IOException::class)
    private fun createTempImageFile(): File {
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val imageFileName = "JPEG_" + timeStamp + "_"
        val storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        return File.createTempFile(imageFileName, ".jpg", storageDir)
    }
}
