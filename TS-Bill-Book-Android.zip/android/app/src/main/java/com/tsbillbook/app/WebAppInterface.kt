package com.tsbillbook.app

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Base64
import android.util.Log
import android.webkit.JavascriptInterface
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream

class WebAppInterface(private val context: Context) {

    private val TAG = "WebAppInterface"

    /**
     * Display a native toast message from the web application
     */
    @JavascriptInterface
    fun showToast(message: String) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }

    /**
     * Native haptic feedback
     */
    @JavascriptInterface
    fun vibrate(milliseconds: Long) {
        val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            vibratorManager.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(milliseconds, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(milliseconds)
        }
    }

    /**
     * Share a generated bill PDF natively
     */
    @JavascriptInterface
    fun shareBill(pdfBase64: String, fileName: String) {
        try {
            // Clean base64 string if it contains prefix data url
            val base64Data = if (pdfBase64.contains(",")) {
                pdfBase64.substring(pdfBase64.indexOf(",") + 1)
            } else {
                pdfBase64
            }

            val pdfAsBytes = Base64.decode(base64Data, Base64.DEFAULT)

            // Save the PDF temporarily inside app cache
            val outputDir = File(context.cacheDir, "shared_bills")
            if (!outputDir.exists()) {
                outputDir.mkdirs()
            }
            val pdfFile = File(outputDir, fileName)
            val fos = FileOutputStream(pdfFile)
            fos.write(pdfAsBytes)
            fos.flush()
            fos.close()

            // Generate content URI using FileProvider
            val fileUri = FileProvider.getUriForFile(
                context,
                "com.tsbillbook.app.fileprovider",
                pdfFile
            )

            // Launch the platform share intent chooser
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, fileUri)
                putExtra(Intent.EXTRA_SUBJECT, "Invoice: $fileName")
                putExtra(Intent.EXTRA_TEXT, "Here is your invoice from TS Bill Book.")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            
            val chooserIntent = Intent.createChooser(shareIntent, "Share Bill").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooserIntent)

        } catch (e: Exception) {
            Log.e(TAG, "Failed to share PDF", e)
            showToast("Failed to share bill: ${e.localizedMessage}")
        }
    }

    /**
     * Identify container environment
     */
    @JavascriptInterface
    fun getPlatform(): String {
        return "android"
    }
}
