#!/bin/bash
# TS Bill Book - Android Sync Script
# Builds the Vite React PWA and copies assets directly into the Android native assets directory.

set -e

echo "============================================="
echo "📊 TS Bill Book - Preparing Android Release..."
echo "============================================="

# 1. Clean old assets
echo "🧹 Cleaning old Android assets..."
rm -rf android/app/src/main/assets
mkdir -p android/app/src/main/assets

# 2. Build the Vite React application
echo "📦 Building React web application..."
npm run build

# 3. Copy compiled static files into Android project assets
echo "🚚 Copying static build into Android native wrapper..."
cp -r dist/* android/app/src/main/assets/

echo "============================================="
echo "✅ SYNC COMPLETED SUCCESSFULLY!"
echo "============================================="
echo "Your offline-first web bundle is now ready in the Android project."
echo "You can now open the '/android' folder in Android Studio and build the project."
echo "- Build Debug APK:  ./gradlew assembleDebug"
echo "- Build Release AAB: ./gradlew bundleRelease"
echo "============================================="
