import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = 3000;

// Body parsing with a high limit to handle image uploads (base64)
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ limit: '10mb', extended: true }));

let aiClient: GoogleGenAI | null = null;

function getGeminiClient(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error('GEMINI_API_KEY is not defined. Please set it in Settings > Secrets.');
    }
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

// API endpoint for AI camera product scanning
app.post('/api/gemini/analyze-product', async (req, res) => {
  try {
    const { image } = req.body;
    if (!image) {
      return res.status(400).json({ error: 'Image data is required' });
    }

    // Clean up base64 prefix if present
    let base64Data = image;
    let mimeType = 'image/jpeg';
    if (image.includes(',')) {
      const parts = image.split(',');
      base64Data = parts[1];
      const match = parts[0].match(/data:(.*?);/);
      if (match && match[1]) {
        mimeType = match[1];
      }
    }

    const ai = getGeminiClient();
    const prompt = 'Identify the retail product in this photo. Return a JSON object containing:\n' +
      '- "productName": the commercial name of the product including packaging size/weight if visible (e.g. "Dettol Liquid Soap 250ml", "Refined Oil 5L", "Basmati Rice 5kg"). Keep it concise but specific.\n' +
      '- "confidence": a decimal number between 0.0 and 1.0 representing how confident you are.\n' +
      '- "suggestedUnit": what selling unit would make sense, chosen from: "pcs", "kg", "box", "pkt", "ltr", "bags", "g", "dz".\n' +
      'If you cannot recognize a clear retail product, set confidence to 0.0 and productName to "Unknown Product". Do not output anything other than raw JSON.';

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: [
        {
          inlineData: {
            mimeType,
            data: base64Data,
          },
        },
        {
          text: prompt,
        },
      ],
      config: {
        responseMimeType: 'application/json',
      },
    });

    const resultText = response.text || '{}';
    let resultJson = { productName: 'Unknown Product', confidence: 0.0, suggestedUnit: 'pcs' };
    try {
      resultJson = JSON.parse(resultText.trim());
    } catch (parseErr) {
      console.error('Error parsing Gemini JSON response:', parseErr, resultText);
    }

    return res.json(resultJson);
  } catch (err: any) {
    console.error('Gemini scanning error:', err);
    return res.status(500).json({ error: err.message || 'An error occurred during scanning.' });
  }
});

// Configure Vite middleware or serve static files
async function setupServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on port ${PORT}`);
  });
}

setupServer();
