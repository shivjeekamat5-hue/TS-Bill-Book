import { useEffect, useState } from 'react';
import { onAuthStateChanged, signOut } from 'firebase/auth';
import { motion, AnimatePresence } from 'motion/react';
import { WifiOff, Sparkles, Smartphone, X } from 'lucide-react';
import { auth, getUserProfile } from './lib/firebase';
import { UserProfile } from './types';
import SplashScreen from './components/SplashScreen';
import AuthPage from './components/AuthPage';
import Dashboard from './components/Dashboard';

export default function App() {
  // Core Application States
  const [appReady, setAppReady] = useState(false);
  const [user, setUser] = useState<any>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [authLoading, setAuthLoading] = useState(true);

  // Styling & Theme States
  const [isDarkMode, setIsDarkMode] = useState(() => {
    const saved = localStorage.getItem('theme');
    if (saved) return saved === 'dark';
    return window.matchMedia('(prefers-color-scheme: dark)').matches;
  });

  // Offline / Network Connection Monitor
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  // PWA Install Prompt State
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [showInstallBanner, setShowInstallBanner] = useState(false);

  // 1. Monitor Online/Offline Status
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // 2. Track PWA Installation Request
  useEffect(() => {
    const handleBeforeInstallPrompt = (e: Event) => {
      // Prevent standard browser bar from displaying
      e.preventDefault();
      // Store the event so it can be triggered later
      setDeferredPrompt(e);
      // Display PWA install banner to the user
      setShowInstallBanner(true);
    };

    const handleAppInstalled = () => {
      console.log('TS Bill Book PWA was successfully installed!');
      setDeferredPrompt(null);
      setShowInstallBanner(false);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    window.addEventListener('appinstalled', handleAppInstalled);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, []);

  // 3. Sync theme class on HTML document
  useEffect(() => {
    const root = window.document.documentElement;
    if (isDarkMode) {
      root.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      root.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  }, [isDarkMode]);

  // 4. Firebase Authentication Listener
  useEffect(() => {
    // Check if we have a saved local-demo-user session
    const isLocalDemo = localStorage.getItem('tsbillbook_local_user') === 'true';
    if (isLocalDemo) {
      setAuthLoading(true);
      getUserProfile('local-demo-user').then((profile) => {
        setUser({ uid: 'local-demo-user', email: 'demo@tsbillbook.com' });
        setUserProfile(profile);
        setAuthLoading(false);
      });
      return;
    }

    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      setAuthLoading(true);
      if (firebaseUser) {
        setUser(firebaseUser);
        try {
          // Fetch custom business profile properties from Firestore
          const profile = await getUserProfile(firebaseUser.uid);
          setUserProfile(profile);
        } catch (err) {
          console.error('Error fetching user profile:', err);
        }
      } else {
        setUser(null);
        setUserProfile(null);
      }
      setAuthLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // Toggle Dark Mode handler
  const handleToggleDarkMode = () => {
    setIsDarkMode(prev => !prev);
  };

  // Trigger PWA installation prompt
  const handleInstallClick = async () => {
    if (!deferredPrompt) return;
    // Show prompt to user
    deferredPrompt.prompt();
    // Await decision
    const { outcome } = await deferredPrompt.userChoice;
    console.log(`PWA Installation outcome: ${outcome}`);
    // Reset event tracker
    setDeferredPrompt(null);
    setShowInstallBanner(false);
  };

  // Stay on Splash Screen until BOTH splash loading timer AND firebase auth checking completes
  const handleSplashComplete = () => {
    setAppReady(true);
  };

  const handleAuthSuccess = async (uid: string) => {
    try {
      if (uid === 'local-demo-user') {
        localStorage.setItem('tsbillbook_local_user', 'true');
        setUser({ uid: 'local-demo-user', email: 'demo@tsbillbook.com' });
      }
      const profile = await getUserProfile(uid);
      setUserProfile(profile);
    } catch (err) {
      console.error(err);
    }
  };

  const showSplashScreen = !appReady || authLoading;

  return (
    <div className="font-sans antialiased selection:bg-brand-200 dark:selection:bg-brand-900 select-none">
      
      {/* 1. SPLASH SCREEN */}
      <AnimatePresence mode="wait">
        {showSplashScreen && (
          <SplashScreen onComplete={handleSplashComplete} />
        )}
      </AnimatePresence>

      {/* 2. CORE APPLICATION SWITCHBOARD */}
      {!showSplashScreen && (
        <div className="min-h-screen flex flex-col">
          {user ? (
            <Dashboard
              userId={user.uid}
              isDarkMode={isDarkMode}
              toggleDarkMode={handleToggleDarkMode}
              onSignOut={async () => {
                setUser(null);
                setUserProfile(null);
                localStorage.removeItem('tsbillbook_local_user');
                try {
                  await signOut(auth);
                } catch (err) {
                  console.error(err);
                }
              }}
              userProfile={userProfile}
              onProfileUpdate={(updated) => setUserProfile(updated)}
              isInstallable={!!deferredPrompt}
              onInstall={handleInstallClick}
            />
          ) : (
            <AuthPage 
              onSuccess={handleAuthSuccess} 
              isDarkMode={isDarkMode} 
            />
          )}

          {/* 3. FLOATING NETWORK OFFLINE TOAST */}
          <AnimatePresence>
            {!isOnline && (
              <motion.div
                initial={{ opacity: 0, y: 50 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 50 }}
                className="fixed bottom-4 left-4 right-4 md:left-auto md:right-6 md:w-96 p-4 bg-amber-500 text-slate-950 rounded-2xl shadow-xl flex items-center gap-3 border border-amber-600 z-50 no-print"
              >
                <div className="p-2 bg-slate-950/15 rounded-xl shrink-0">
                  <WifiOff className="w-5 h-5" />
                </div>
                <div className="flex-1">
                  <h4 className="font-extrabold text-sm leading-none">Connection Lost</h4>
                  <p className="text-[11px] font-medium opacity-90 mt-1">Working offline. Ledger edits are saved locally.</p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* 4. PWA SYSTEM APP INSTALL PROMOTION BANNER */}
          <AnimatePresence>
            {showInstallBanner && (
              <motion.div
                initial={{ opacity: 0, y: 100 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 100 }}
                className="fixed bottom-4 left-4 right-4 md:left-6 md:right-auto md:w-96 p-4 bg-gradient-to-r from-slate-900 via-slate-950 to-slate-900 text-white rounded-3xl shadow-2xl border border-slate-850 flex items-center justify-between gap-4 z-50 no-print"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-brand-500/10 text-brand-500 flex items-center justify-center shrink-0">
                    <Smartphone className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-xs flex items-center gap-1">
                      TS Bill Book PWA <Sparkles className="w-3 h-3 text-yellow-400 fill-yellow-400" />
                    </h4>
                    <p className="text-[10px] text-slate-400 mt-0.5">Install on home screen for fast access</p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleInstallClick}
                    className="px-3.5 py-1.5 bg-brand-500 hover:bg-brand-600 text-xs font-bold rounded-xl text-slate-950 shadow-md transition cursor-pointer"
                  >
                    Install
                  </button>
                  <button
                    onClick={() => setShowInstallBanner(false)}
                    className="p-1 rounded-full text-slate-500 hover:text-slate-300 transition"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
}
