import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Users, 
  Search, 
  ArrowLeft, 
  User, 
  Building, 
  Phone, 
  MapPin, 
  FileText, 
  TrendingUp, 
  Coins, 
  AlertTriangle,
  Shield,
  Loader2
} from 'lucide-react';
import { UserProfile, Shopkeeper, Bill } from '../types';
import { getAllUsers, getShopkeepers, getBills } from '../lib/firebase';

interface AdminPanelProps {
  isDarkMode: boolean;
  onBack: () => void;
}

export default function AdminPanel({ isDarkMode, onBack }: AdminPanelProps) {
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  
  // Selected user for deep inspection
  const [selectedUser, setSelectedUser] = useState<UserProfile | null>(null);
  const [selectedUserShopkeepers, setSelectedUserShopkeepers] = useState<Shopkeeper[]>([]);
  const [selectedUserBills, setSelectedUserBills] = useState<Bill[]>([]);
  const [inspectLoading, setInspectLoading] = useState(false);

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    setLoading(true);
    try {
      const allUsers = await getAllUsers();
      // Keep shivjeekamat5@gmail.com at the top as owner
      const sorted = [...allUsers].sort((a, b) => {
        if (a.email === 'shivjeekamat5@gmail.com') return -1;
        if (b.email === 'shivjeekamat5@gmail.com') return 1;
        return (a.email || '').localeCompare(b.email || '');
      });
      setUsers(sorted);
    } catch (err) {
      console.error('Error fetching users:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleInspectUser = async (userProfile: UserProfile) => {
    setSelectedUser(userProfile);
    setInspectLoading(true);
    try {
      const shopkeepers = await getShopkeepers(userProfile.uid);
      const bills = await getBills(userProfile.uid);
      setSelectedUserShopkeepers(shopkeepers);
      setSelectedUserBills(bills);
    } catch (err) {
      console.error('Error inspecting user:', err);
    } finally {
      setInspectLoading(false);
    }
  };

  const filteredUsers = users.filter(u => {
    const term = searchQuery.toLowerCase();
    return (u.email || '').toLowerCase().includes(term) || 
           (u.businessName || '').toLowerCase().includes(term) ||
           (u.displayName || '').toLowerCase().includes(term);
  });

  // Calculations for selected user
  const totalPaid = selectedUserBills.filter(b => b.paymentStatus === 'paid').reduce((sum, b) => sum + b.grandTotal, 0);
  const totalPending = selectedUserBills.filter(b => b.paymentStatus !== 'paid').reduce((sum, b) => sum + b.grandTotal, 0);

  return (
    <div className="p-4 md:p-6 max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <button
          onClick={selectedUser ? () => setSelectedUser(null) : onBack}
          className={`p-2 rounded-xl border transition ${
            isDarkMode 
              ? 'border-slate-800 bg-slate-900 text-slate-300 hover:bg-slate-800' 
              : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
          }`}
          title="Go Back"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>
        <div>
          <span className="text-[9px] uppercase font-mono tracking-widest text-slate-450 dark:text-slate-500">Super Admin Control</span>
          <h2 className="text-xl font-black flex items-center gap-2">
            <Shield className="w-5 h-5 text-emerald-500 fill-emerald-500/10" />
            {selectedUser ? `Inspecting: ${selectedUser.businessName || selectedUser.email}` : 'TS Bill Book Admin Panel'}
          </h2>
        </div>
      </div>

      <AnimatePresence mode="wait">
        {!selectedUser ? (
          // USER LIST VIEW
          <motion.div
            key="user-list"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            className="space-y-4"
          >
            {/* Search and Stats bar */}
            <div className="flex flex-col sm:flex-row gap-3 justify-between items-center">
              <div className="relative w-full sm:max-w-xs">
                <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center text-slate-400">
                  <Search className="w-4 h-4" />
                </span>
                <input
                  type="text"
                  placeholder="Search user, business..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className={`w-full pl-10 pr-4 py-2.5 rounded-2xl border text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-brand-500/20 focus:border-brand-500 transition-all ${
                    isDarkMode 
                      ? 'bg-slate-900 border-slate-800 text-white' 
                      : 'bg-white border-slate-200 text-slate-950'
                  }`}
                />
              </div>

              <div className="text-xs font-bold text-slate-400">
                Total Registered Users: {users.length}
              </div>
            </div>

            {loading ? (
              <div className="py-20 text-center text-sm text-slate-500 flex flex-col items-center justify-center gap-2">
                <Loader2 className="w-8 h-8 text-brand-500 animate-spin" />
                Fetching secure user ledger databases...
              </div>
            ) : filteredUsers.length === 0 ? (
              <div className="py-20 text-center text-xs text-slate-500 italic">
                No users matched your query.
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {filteredUsers.map((u) => {
                  const isSystemOwner = u.email === 'shivjeekamat5@gmail.com';
                  return (
                    <div
                      key={u.uid}
                      onClick={() => handleInspectUser(u)}
                      className={`p-5 rounded-3xl border shadow-sm cursor-pointer transition-all hover:scale-[1.01] flex flex-col justify-between gap-4 ${
                        isDarkMode 
                          ? 'bg-slate-900 border-slate-800 hover:border-slate-700' 
                          : 'bg-white border-slate-100 hover:border-slate-200'
                      }`}
                    >
                      <div className="space-y-3">
                        <div className="flex justify-between items-start gap-2">
                          <div className="flex items-center gap-3">
                            <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                              isSystemOwner 
                                ? 'bg-emerald-500/10 text-emerald-500' 
                                : 'bg-brand-500/10 text-brand-500'
                            }`}>
                              {isSystemOwner ? <Shield className="w-5 h-5" /> : <User className="w-5 h-5" />}
                            </div>
                            <div>
                              <h4 className="font-extrabold text-sm leading-tight line-clamp-1">
                                {u.businessName || 'Unnamed Ledger Book'}
                              </h4>
                              <p className="text-[10px] text-slate-400 font-mono mt-0.5 line-clamp-1">{u.email}</p>
                            </div>
                          </div>

                          <span className={`text-[9px] px-2.5 py-0.5 rounded-full font-extrabold uppercase tracking-wider ${
                            isSystemOwner 
                              ? 'bg-emerald-500/10 text-emerald-500 border border-emerald-500/20' 
                              : 'bg-slate-500/10 text-slate-400 border border-slate-500/10'
                          }`}>
                            {isSystemOwner ? 'Owner & Admin' : 'Merchant'}
                          </span>
                        </div>

                        <div className="border-t border-slate-100 dark:border-slate-800 pt-3 space-y-1.5 text-xs text-slate-500">
                          <div className="flex items-center gap-2">
                            <User className="w-3.5 h-3.5 text-slate-400" />
                            <span>Merchant: {u.displayName || u.email.split('@')[0]}</span>
                          </div>
                          {u.businessPhone && (
                            <div className="flex items-center gap-2">
                              <Phone className="w-3.5 h-3.5 text-slate-400" />
                              <span className="font-mono">{u.businessPhone}</span>
                            </div>
                          )}
                          {u.businessAddress && (
                            <div className="flex items-center gap-2">
                              <MapPin className="w-3.5 h-3.5 text-slate-400" />
                              <span className="line-clamp-1">{u.businessAddress}</span>
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="text-[10px] text-right font-mono text-slate-400 dark:text-slate-500 border-t border-slate-50 dark:border-slate-850/50 pt-2.5">
                        UID: {u.uid.substring(0, 12)}...
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </motion.div>
        ) : (
          // USER INSPECTION/DEEP-DIVE VIEW
          <motion.div
            key="user-inspect"
            initial={{ opacity: 0, y: -15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 15 }}
            className="space-y-6"
          >
            {/* Merchant info block */}
            <div className={`p-6 rounded-3xl border ${
              isDarkMode ? 'bg-gradient-to-br from-slate-900 to-slate-950 border-slate-800' : 'bg-white border-slate-100'
            }`}>
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-brand-500/10 text-brand-500 flex items-center justify-center">
                    <Building className="w-6 h-6" />
                  </div>
                  <div>
                    <span className="text-[9px] uppercase font-mono tracking-widest text-slate-400">Inspecting Ledger</span>
                    <h3 className="text-xl font-black">{selectedUser.businessName || 'TS Ledger Store'}</h3>
                    <p className="text-xs text-slate-500">Merchant: {selectedUser.displayName || selectedUser.email.split('@')[0]} | {selectedUser.email}</p>
                  </div>
                </div>
                <button
                  onClick={() => setSelectedUser(null)}
                  className="px-4 py-2 text-xs font-bold bg-brand-500 hover:bg-brand-600 text-slate-950 rounded-xl shadow-md transition"
                >
                  Back to User List
                </button>
              </div>
            </div>

            {inspectLoading ? (
              <div className="py-20 text-center text-sm text-slate-500 flex flex-col items-center justify-center gap-2">
                <Loader2 className="w-8 h-8 text-brand-500 animate-spin" />
                Loading ledger records for this merchant...
              </div>
            ) : (
              <>
                {/* Metrics */}
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                  <div className={`p-5 rounded-3xl border shadow-sm ${
                    isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100'
                  }`}>
                    <div className="flex justify-between items-center mb-3">
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Customers</span>
                      <Users className="w-4 h-4 text-cyan-500" />
                    </div>
                    <h4 className="text-2xl font-black font-mono text-cyan-500">
                      {selectedUserShopkeepers.length}
                    </h4>
                    <p className="text-[10px] text-slate-500 mt-1">Total ledger accounts</p>
                  </div>

                  <div className={`p-5 rounded-3xl border shadow-sm ${
                    isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100'
                  }`}>
                    <div className="flex justify-between items-center mb-3">
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Total Invoices</span>
                      <FileText className="w-4 h-4 text-amber-500" />
                    </div>
                    <h4 className="text-2xl font-black font-mono text-amber-600 dark:text-amber-500">
                      {selectedUserBills.length}
                    </h4>
                    <p className="text-[10px] text-slate-500 mt-1">Issued bills count</p>
                  </div>

                  <div className={`p-5 rounded-3xl border shadow-sm ${
                    isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100'
                  }`}>
                    <div className="flex justify-between items-center mb-3">
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Total Settled</span>
                      <Coins className="w-4 h-4 text-emerald-500" />
                    </div>
                    <h4 className="text-2xl font-black font-mono text-emerald-600 dark:text-emerald-500">
                      ₹{totalPaid.toFixed(2)}
                    </h4>
                    <p className="text-[10px] text-slate-500 mt-1">Collected payment</p>
                  </div>

                  <div className={`p-5 rounded-3xl border shadow-sm ${
                    isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100'
                  }`}>
                    <div className="flex justify-between items-center mb-3">
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Dues / Pending</span>
                      <AlertTriangle className="w-4 h-4 text-rose-500" />
                    </div>
                    <h4 className="text-2xl font-black font-mono text-rose-600 dark:text-rose-500">
                      ₹{totalPending.toFixed(2)}
                    </h4>
                    <p className="text-[10px] text-slate-500 mt-1">Outstanding business credit</p>
                  </div>
                </div>

                {/* Subsections: Customers and Bills */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Customers */}
                  <div className="space-y-3">
                    <h4 className="font-extrabold text-sm uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                      <Users className="w-4 h-4 text-brand-500" />
                      Merchant's Customers ({selectedUserShopkeepers.length})
                    </h4>
                    <div className={`border rounded-3xl max-h-96 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800 ${
                      isDarkMode ? 'bg-slate-900 border-slate-800 divide-slate-800' : 'bg-white border-slate-100 divide-slate-100'
                    }`}>
                      {selectedUserShopkeepers.length === 0 ? (
                        <p className="p-8 text-center text-xs text-slate-500 italic">No customer ledger setup yet.</p>
                      ) : (
                        selectedUserShopkeepers.map(sk => (
                          <div key={sk.id} className="p-4 flex justify-between items-center">
                            <div>
                              <h5 className="font-extrabold text-xs">{sk.name}</h5>
                              <p className="text-[9px] text-slate-400 mt-0.5">{sk.category} | {sk.phone || 'No Phone'}</p>
                            </div>
                            {sk.balance !== undefined && (
                              <span className={`text-xs font-bold font-mono ${
                                sk.balance > 0 
                                  ? 'text-red-500' 
                                  : sk.balance < 0 
                                    ? 'text-emerald-500' 
                                    : 'text-slate-400'
                              }`}>
                                {sk.balance > 0 ? `₹${sk.balance} (Due)` : sk.balance < 0 ? `₹${Math.abs(sk.balance)} (Advance)` : '₹0'}
                              </span>
                            )}
                          </div>
                        ))
                      )}
                    </div>
                  </div>

                  {/* Recent Bills */}
                  <div className="space-y-3">
                    <h4 className="font-extrabold text-sm uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                      <FileText className="w-4 h-4 text-brand-500" />
                      Recent Bills ({selectedUserBills.length})
                    </h4>
                    <div className={`border rounded-3xl max-h-96 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800 ${
                      isDarkMode ? 'bg-slate-900 border-slate-800 divide-slate-800' : 'bg-white border-slate-100 divide-slate-100'
                    }`}>
                      {selectedUserBills.length === 0 ? (
                        <p className="p-8 text-center text-xs text-slate-500 italic">No invoices issued yet.</p>
                      ) : (
                        selectedUserBills.map(bill => (
                          <div key={bill.id} className="p-4 flex justify-between items-center">
                            <div>
                              <h5 className="font-extrabold text-xs">{bill.shopkeeperName}</h5>
                              <p className="text-[9px] text-slate-400 font-mono mt-0.5">
                                {new Date(bill.date).toLocaleDateString('en-IN', { day: '2-digit', month: 'short' })} • {bill.items.length} items
                              </p>
                            </div>
                            <div className="text-right">
                              <p className="font-mono text-xs font-black text-emerald-600 dark:text-emerald-500">₹{bill.grandTotal.toFixed(2)}</p>
                              <span className={`text-[8px] font-bold px-1 rounded ${
                                bill.paymentStatus === 'paid' 
                                  ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400' 
                                  : bill.paymentStatus === 'partial'
                                    ? 'bg-amber-500/10 text-amber-600 dark:text-amber-400'
                                    : 'bg-red-500/10 text-red-600 dark:text-red-400'
                              }`}>
                                {bill.paymentStatus?.toUpperCase() || 'UNPAID'}
                              </span>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                </div>
              </>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
