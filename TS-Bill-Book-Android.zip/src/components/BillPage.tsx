import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ArrowLeft, 
  Calendar, 
  Plus, 
  Trash2, 
  Save, 
  Printer, 
  Share2, 
  History, 
  Search, 
  FileText, 
  AlertTriangle,
  Sparkles,
  ChevronDown,
  Camera
} from 'lucide-react';
import { Shopkeeper, Bill, BillItem } from '../types';
import { saveBill, getShopkeeperBills, deleteBill, updateBill } from '../lib/firebase';
import CameraScanModal from './CameraScanModal';

interface BillPageProps {
  userId: string;
  shopkeeper: Shopkeeper;
  onBack: () => void;
  isDarkMode: boolean;
  businessProfile?: any;
}

// Common items for smart autocomplete suggestions
const COMMON_ITEMS = [
  'Sugar', 'Rice', 'Wheat Flour', 'Cooking Oil', 'Soap', 'Shampoo', 'Toothpaste',
  'Milk', 'Bread', 'Butter', 'Eggs', 'Tea Powder', 'Coffee Beans', 'Salt', 'Dal / Pulses',
  'Paracetamol', 'Bandage', 'Cough Syrup', 'Antiseptic Liquid', 'Aspirin',
  'Tomato', 'Potato', 'Onion', 'Garlic', 'Ginger', 'Apple', 'Banana', 'Mango',
  'Cold Drink', 'Mineral Water', 'Biscuit Packet', 'Namkeen', 'Chocolates',
  'Notebook', 'Pen', 'Pencil', 'A4 Paper', 'Matches', 'Candles', 'Battery Cells'
];

const UNITS = ['pcs', 'kg', 'box', 'pkt', 'ltr', 'bags', 'g', 'dz'];

export default function BillPage({ userId, shopkeeper, onBack, isDarkMode, businessProfile }: BillPageProps) {
  // Date State - Defaults to Today (YYYY-MM-DD in local timezone)
  const getTodayDateString = () => {
    const today = new Date();
    const offset = today.getTimezoneOffset();
    const localToday = new Date(today.getTime() - (offset * 60 * 1000));
    return localToday.toISOString().split('T')[0];
  };

  const [billDate, setBillDate] = useState(getTodayDateString());
  
  // Bill History & Active Bill
  const [billsHistory, setBillsHistory] = useState<Bill[]>([]);
  const [selectedBillId, setSelectedBillId] = useState<string | null>(null); // null means editing a "New Bill"
  const [historyLoading, setHistoryLoading] = useState(false);

  // Bill Items
  const [items, setItems] = useState<BillItem[]>([
    { id: '1', name: '', quantity: 1, pieces: 'pcs', price: 0, total: 0 }
  ]);
  const [notes, setNotes] = useState('');

  // Autocomplete UI states per row
  const [activeRowId, setActiveRowId] = useState<string | null>(null);
  const [itemSearchText, setItemSearchText] = useState('');

  // Save states
  const [saving, setSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Delete Confirm Popup
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  // AI Camera Scan Modal
  const [isScanModalOpen, setIsScanModalOpen] = useState(false);

  // Payment states
  const [paymentStatus, setPaymentStatus] = useState<'paid' | 'unpaid' | 'partial'>('unpaid');
  const [paymentDate, setPaymentDate] = useState('');
  const [manualGrandTotal, setManualGrandTotal] = useState('');
  const [historyFilter, setHistoryFilter] = useState<'all' | 'paid' | 'unpaid' | 'partial'>('all');

  useEffect(() => {
    const calculatedTotal = items.reduce((sum, item) => sum + (item.total || 0), 0);
    setManualGrandTotal(calculatedTotal === 0 ? '' : calculatedTotal.toString());
  }, [items]);

  // Handle scanned product
  const handleProductScanComplete = (product: { name: string; quantity: number; pieces: string; price: number }) => {
    setItems((prevItems) => {
      const isLastItemEmpty = prevItems.length > 0 && prevItems[prevItems.length - 1].name.trim() === '' && prevItems[prevItems.length - 1].price === 0;
      const newItem: BillItem = {
        id: isLastItemEmpty ? prevItems[prevItems.length - 1].id : (Date.now() + Math.random()).toString(),
        name: product.name,
        quantity: product.quantity,
        pieces: product.pieces,
        price: product.price,
        total: Number((product.quantity * product.price).toFixed(2))
      };

      if (isLastItemEmpty) {
        const updated = [...prevItems];
        updated[updated.length - 1] = newItem;
        return updated;
      } else {
        if (prevItems.length === 1 && prevItems[0].name.trim() === '' && prevItems[0].price === 0) {
          return [newItem];
        }
        return [...prevItems, newItem];
      }
    });
  };

  // Load history of bills for this shopkeeper
  const loadBillHistory = async () => {
    setHistoryLoading(true);
    try {
      const records = await getShopkeeperBills(userId, shopkeeper.id);
      setBillsHistory(records);
    } catch (err) {
      console.error('Error loading bill history:', err);
    } finally {
      setHistoryLoading(false);
    }
  };

  useEffect(() => {
    loadBillHistory();
    startNewBill();
  }, [shopkeeper.id]);

  // Calculate row total dynamically
  const updateRowTotal = (rowId: string, updatedFields: Partial<BillItem>) => {
    setItems((prevItems) =>
      prevItems.map((item) => {
        if (item.id === rowId) {
          const newItem = { ...item, ...updatedFields };
          // Calculate total: quantity * price
          newItem.total = Number((newItem.quantity * newItem.price).toFixed(2));
          return newItem;
        }
        return item;
      })
    );
  };

  // Add empty row
  const addRow = () => {
    const newId = (items.length + 1).toString();
    setItems([
      ...items,
      { id: newId, name: '', quantity: 1, pieces: 'pcs', price: 0, total: 0 }
    ]);
  };

  // Delete row
  const deleteRow = (rowId: string) => {
    if (items.length === 1) {
      setItems([{ id: '1', name: '', quantity: 1, pieces: 'pcs', price: 0, total: 0 }]);
    } else {
      setItems(items.filter((item) => item.id !== rowId));
    }
  };

  // Calculate Grand Total
  const grandTotal = items.reduce((sum, item) => sum + (item.total || 0), 0);

  // Set Bill Mode to "New Bill"
  const startNewBill = () => {
    setSelectedBillId(null);
    setBillDate(getTodayDateString());
    
    const initialItems = shopkeeper.monthlyBillAmount 
      ? [{ id: '1', name: 'Monthly Bill', quantity: 1, pieces: 'pcs', price: shopkeeper.monthlyBillAmount, total: shopkeeper.monthlyBillAmount }]
      : [{ id: '1', name: '', quantity: 1, pieces: 'pcs', price: 0, total: 0 }];
      
    setItems(initialItems);
    setNotes('');
    setPaymentStatus('unpaid');
    setPaymentDate('');
    setManualGrandTotal(shopkeeper.monthlyBillAmount ? shopkeeper.monthlyBillAmount.toString() : '');
    setSaveSuccess(false);
  };

  // Load old bill for viewing/editing
  const loadOldBill = (bill: Bill) => {
    setSelectedBillId(bill.id);
    setBillDate(bill.date);
    setItems(bill.items);
    setNotes(bill.notes || '');
    setPaymentStatus(bill.paymentStatus || 'unpaid');
    setPaymentDate(bill.paymentDate || '');
    setManualGrandTotal(bill.grandTotal.toString());
    setSaveSuccess(false);
  };

  // Mark as Paid Helper
  const handleMarkAsPaid = async (billId?: string) => {
    const today = getTodayDateString();
    if (billId) {
      try {
        await updateBill(userId, billId, {
          paymentStatus: 'paid',
          paymentDate: today
        });
        await loadBillHistory();
        if (selectedBillId === billId) {
          setPaymentStatus('paid');
          setPaymentDate(today);
        }
      } catch (err) {
        console.error('Error marking as paid:', err);
      }
    } else {
      setPaymentStatus('paid');
      setPaymentDate(today);
      if (selectedBillId) {
        setSaving(true);
        try {
          const finalGrandTotal = manualGrandTotal ? Number(manualGrandTotal) : grandTotal;
          const validItems = items.filter(item => item.name.trim() !== '');
          await updateBill(userId, selectedBillId, {
            paymentStatus: 'paid',
            paymentDate: today,
            grandTotal: Number(finalGrandTotal.toFixed(2))
          });
          setSaveSuccess(true);
          await loadBillHistory();
          setTimeout(() => setSaveSuccess(false), 3000);
        } catch (err) {
          console.error(err);
        } finally {
          setSaving(false);
        }
      }
    }
  };

  // Save current bill to Firestore
  const handleSaveBill = async () => {
    const validItems = items.filter(item => item.name.trim() !== '');
    const finalGrandTotal = manualGrandTotal ? Number(manualGrandTotal) : grandTotal;
    
    if (validItems.length === 0 && finalGrandTotal <= 0) {
      alert('Please enter at least one item name or set a bill amount.');
      return;
    }

    setSaving(true);
    try {
      const billData = {
        shopkeeperId: shopkeeper.id,
        shopkeeperName: shopkeeper.name,
        date: billDate,
        items: validItems,
        grandTotal: Number(finalGrandTotal.toFixed(2)),
        notes: notes.trim(),
        paymentStatus,
        paymentDate: paymentStatus === 'paid' ? (paymentDate || getTodayDateString()) : (paymentStatus === 'partial' ? paymentDate : '')
      };

      if (selectedBillId) {
        // Update existing bill
        await updateBill(userId, selectedBillId, billData);
      } else {
        // Create new bill
        const saved = await saveBill(userId, billData);
        setSelectedBillId(saved.id);
      }
      
      setSaveSuccess(true);
      await loadBillHistory(); // reload lists

      // Hide success flag after 3 seconds
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (err) {
      console.error('Error saving bill:', err);
      alert('Failed to save bill. Please check your network.');
    } finally {
      setSaving(false);
    }
  };

  // Delete selected bill
  const handleDeleteBill = async () => {
    if (!deleteConfirmId) return;
    try {
      await deleteBill(userId, deleteConfirmId);
      setDeleteConfirmId(null);
      startNewBill();
      await loadBillHistory();
    } catch (err) {
      console.error('Error deleting bill:', err);
      alert('Failed to delete bill.');
    }
  };

  // WhatsApp Message Formatter & Opener
  const handleWhatsAppShare = () => {
    const activeItems = items.filter(item => item.name.trim() !== '');
    if (activeItems.length === 0) return;

    let text = `*TS Bill Book - Invoice Memo*\n`;
    text += `*Shop:* ${businessProfile?.businessName || 'TS Bill Book Store'}\n`;
    text += `*Date:* ${billDate}\n`;
    text += `*Customer:* ${shopkeeper.name}\n`;
    text += `--------------------------------------\n`;
    
    activeItems.forEach((item, index) => {
      text += `${index + 1}. *${item.name}* (${item.quantity} ${item.pieces}) @ ₹${item.price} = *₹${item.total}*\n`;
    });
    
    text += `--------------------------------------\n`;
    text += `*Grand Total: ₹${grandTotal.toFixed(2)}*\n\n`;
    if (notes) {
      text += `*Note:* ${notes}\n`;
    }
    text += `_Thank you for your business!_`;

    const encodedText = encodeURIComponent(text);
    const phoneNo = shopkeeper.phone ? shopkeeper.phone.replace(/\D/g, '') : '';
    const whatsappUrl = `https://wa.me/${phoneNo ? '91' + phoneNo : ''}?text=${encodedText}`;
    window.open(whatsappUrl, '_blank');
  };

  // Browser-level layout trigger
  const handlePrint = () => {
    window.print();
  };

  // Helper date labels
  const getRelativeDateLabel = (dateStr: string) => {
    const todayStr = getTodayDateString();
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayStr = yesterday.toISOString().split('T')[0];

    if (dateStr === todayStr) return 'Today';
    if (dateStr === yesterdayStr) return 'Yesterday';
    return new Date(dateStr).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
  };

  return (
    <div className="flex flex-col lg:flex-row gap-6 p-4 md:p-6 h-full select-text">
      
      {/* LEFT COMPONENT: Invoice Creator / Editor */}
      <div className="flex-1 flex flex-col print-card no-print">
        
        {/* Header Action Row */}
        <div className="flex items-center justify-between mb-4 gap-2">
          <button
            onClick={onBack}
            className={`inline-flex items-center gap-1 px-3 py-1.5 text-xs font-bold rounded-lg transition-all ${
              isDarkMode ? 'hover:bg-slate-800 text-slate-300' : 'hover:bg-slate-100 text-slate-700'
            }`}
          >
            <ArrowLeft className="w-4 h-4" /> Back to List
          </button>

          <div className="flex items-center gap-2">
            {selectedBillId && (
              <button
                onClick={startNewBill}
                className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-bold rounded-lg bg-brand-500/10 text-brand-500 hover:bg-brand-500/20"
              >
                + New Bill
              </button>
            )}

            {selectedBillId && (
              <button
                onClick={() => setDeleteConfirmId(selectedBillId)}
                className="p-1.5 rounded-lg text-red-500 hover:bg-red-500/10 transition"
                title="Delete this invoice"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Invoice Worksheet Form */}
        <div className={`p-5 rounded-3xl border shadow-md flex-1 flex flex-col ${
          isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100'
        }`}>
          
          {/* Shopkeeper and Meta Information */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-dashed dark:border-slate-800 mb-4">
            <div>
              <p className="text-[10px] uppercase font-mono tracking-wider text-slate-400">Shopkeeper / Customer</p>
              <h2 className="text-xl font-extrabold text-brand-600 dark:text-brand-500 flex items-center gap-2">
                {shopkeeper.name}
              </h2>
              <p className="text-xs text-slate-500 mt-0.5 flex flex-wrap items-center gap-2">
                <span>{shopkeeper.category} • {shopkeeper.phone || 'No Phone'}</span>
                {shopkeeper.monthlyBillAmount !== undefined && (
                  <span className="px-2 py-0.5 bg-brand-500/10 text-brand-600 dark:text-brand-400 rounded-md font-semibold text-[10px]">
                    Monthly: ₹{shopkeeper.monthlyBillAmount}
                  </span>
                )}
              </p>
            </div>

            {/* Actions & Date Selector */}
            <div className="flex flex-wrap items-center gap-3 self-start md:self-auto">
              {/* AI Camera Scan Button */}
              <button
                type="button"
                onClick={() => setIsScanModalOpen(true)}
                className="inline-flex items-center gap-1.5 px-4.5 py-2 bg-gradient-to-r from-purple-600 via-brand-500 to-emerald-500 hover:from-purple-700 hover:to-emerald-600 text-white text-xs font-black rounded-xl shadow-md transition cursor-pointer active:scale-95 hover:shadow-brand-500/10"
              >
                <Sparkles className="w-3.5 h-3.5 text-yellow-300 fill-yellow-300 animate-pulse" />
                <span>AI Camera Scan</span>
              </button>

              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-slate-400 shrink-0" />
                <input
                  type="date"
                  value={billDate}
                  onChange={(e) => setBillDate(e.target.value)}
                  className={`px-3 py-1.5 rounded-lg border text-sm font-semibold focus:outline-none focus:ring-1 focus:ring-brand-500 ${
                    isDarkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-slate-50 border-slate-200 text-slate-900'
                  }`}
                />
              </div>
            </div>
          </div>

          {/* TABLE CONTAINER: Bill Line Items */}
          <div className="overflow-x-auto -mx-5 px-5 flex-1 min-h-[220px]">
            <table className="w-full text-left border-collapse font-sans">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-400 text-xs font-bold uppercase tracking-wider">
                  <th className="py-2.5 w-12 text-center">S.No</th>
                  <th className="py-2.5 min-w-[150px]">Item Name</th>
                  <th className="py-2.5 w-20 text-center">Qty</th>
                  <th className="py-2.5 w-20 text-center">Pieces</th>
                  <th className="py-2.5 w-24 text-right">Price (₹)</th>
                  <th className="py-2.5 w-24 text-right pr-2">Total (₹)</th>
                  <th className="py-2.5 w-10 text-center no-print"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800/50">
                {items.map((item, index) => (
                  <tr key={item.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-900/30 group">
                    {/* Serial No */}
                    <td className="py-2.5 text-center text-sm font-mono text-slate-500">
                      {index + 1}
                    </td>

                    {/* Item Name with Suggestions */}
                    <td className="py-2 relative">
                      <input
                        type="text"
                        placeholder="Type item name..."
                        value={item.name}
                        onChange={(e) => {
                          const val = e.target.value;
                          updateRowTotal(item.id, { name: val });
                          setItemSearchText(val);
                          setActiveRowId(item.id);
                        }}
                        onFocus={() => {
                          setItemSearchText(item.name);
                          setActiveRowId(item.id);
                        }}
                        className={`w-full px-2 py-1.5 rounded-lg border text-sm focus:outline-none focus:ring-1 focus:ring-brand-500 transition-colors ${
                          isDarkMode ? 'bg-slate-950 border-slate-850 text-white' : 'bg-white border-slate-200'
                        }`}
                      />
                      
                      {/* Autocomplete Dropdown */}
                      <AnimatePresence>
                        {activeRowId === item.id && (
                          <>
                            {/* Overlay to close suggestion */}
                            <div className="fixed inset-0 z-10" onClick={() => setActiveRowId(null)} />
                            
                            <motion.ul
                              initial={{ opacity: 0, y: 5 }}
                              animate={{ opacity: 1, y: 0 }}
                              exit={{ opacity: 0 }}
                              className={`absolute left-0 right-0 mt-1 max-h-48 overflow-y-auto rounded-xl shadow-lg border z-20 divide-y ${
                                isDarkMode 
                                  ? 'bg-slate-900 border-slate-800 text-slate-200 divide-slate-800' 
                                  : 'bg-white border-slate-200 text-slate-800 divide-slate-100'
                              }`}
                            >
                              <li className="p-1.5 text-[10px] font-mono text-slate-400 dark:text-slate-500 uppercase">Suggestions</li>
                              {COMMON_ITEMS.filter(it => 
                                it.toLowerCase().includes(itemSearchText.toLowerCase())
                              ).map(suggestedName => (
                                <li key={suggestedName}>
                                  <button
                                    type="button"
                                    onClick={() => {
                                      updateRowTotal(item.id, { name: suggestedName });
                                      setActiveRowId(null);
                                    }}
                                    className="w-full text-left px-3 py-2 text-xs hover:bg-brand-500 hover:text-white transition"
                                  >
                                    {suggestedName}
                                  </button>
                                </li>
                              ))}
                              {COMMON_ITEMS.filter(it => 
                                it.toLowerCase().includes(itemSearchText.toLowerCase())
                              ).length === 0 && (
                                <li className="px-3 py-2 text-xs text-slate-400 italic">No exact match, press Tab</li>
                              )}
                            </motion.ul>
                          </>
                        )}
                      </AnimatePresence>
                    </td>

                    {/* Quantity */}
                    <td className="py-2 text-center">
                      <input
                        type="number"
                        min={0.01}
                        step="any"
                        value={item.quantity === 0 ? '' : item.quantity}
                        onChange={(e) => updateRowTotal(item.id, { quantity: Number(e.target.value) })}
                        className={`w-16 px-1.5 py-1 text-center rounded-lg border text-sm font-mono focus:outline-none focus:ring-1 focus:ring-brand-500 ${
                          isDarkMode ? 'bg-slate-950 border-slate-850 text-white' : 'bg-white border-slate-200'
                        }`}
                      />
                    </td>

                    {/* Pieces (Unit Selection) */}
                    <td className="py-2 text-center">
                      <select
                        value={item.pieces}
                        onChange={(e) => updateRowTotal(item.id, { pieces: e.target.value })}
                        className={`w-18 px-1 py-1 rounded-lg border text-xs focus:outline-none focus:ring-1 focus:ring-brand-500 cursor-pointer ${
                          isDarkMode ? 'bg-slate-950 border-slate-850 text-white' : 'bg-white border-slate-200'
                        }`}
                      >
                        {UNITS.map(u => (
                          <option key={u} value={u}>{u}</option>
                        ))}
                      </select>
                    </td>

                    {/* Price */}
                    <td className="py-2 text-right">
                      <input
                        type="number"
                        min={0}
                        step="any"
                        placeholder="0.00"
                        value={item.price === 0 ? '' : item.price}
                        onChange={(e) => updateRowTotal(item.id, { price: Number(e.target.value) })}
                        className={`w-20 px-2 py-1 text-right rounded-lg border text-sm font-mono focus:outline-none focus:ring-1 focus:ring-brand-500 ${
                          isDarkMode ? 'bg-slate-950 border-slate-850 text-white' : 'bg-white border-slate-200'
                        }`}
                      />
                    </td>

                    {/* Total Row Price */}
                    <td className="py-2 text-right font-mono text-sm font-bold pr-2">
                      ₹{item.total.toFixed(2)}
                    </td>

                    {/* Trash Button */}
                    <td className="py-2 text-center no-print">
                      <button
                        onClick={() => deleteRow(item.id)}
                        className="p-1 rounded-full text-slate-400 hover:text-red-500 hover:bg-slate-100 dark:hover:bg-slate-800 opacity-0 group-hover:opacity-100 transition-all"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Add Row Trigger */}
          <div className="pt-3 no-print">
            <button
              onClick={addRow}
              className={`inline-flex items-center gap-1 px-4 py-2 text-xs font-bold rounded-xl border transition-all cursor-pointer ${
                isDarkMode 
                  ? 'border-slate-800 hover:bg-slate-800 text-brand-500' 
                  : 'border-slate-200 hover:bg-slate-50 text-brand-600'
              }`}
            >
              <Plus className="w-4 h-4" /> Add Item Line
            </button>
          </div>

          {/* Footer Ledger: Notes & Grand Totals */}
          <div className="mt-4 pt-4 border-t border-dashed dark:border-slate-800 flex flex-col md:flex-row md:items-end justify-between gap-4">
            
            {/* Notes textarea */}
            <div className="flex-1 max-w-sm no-print">
              <label className="block text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1">
                Bill Note / Remarks (Optional)
              </label>
              <textarea
                placeholder="e.g., Paid via UPI, pending due..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                rows={2}
                className={`w-full px-3 py-1.5 rounded-xl border text-xs focus:outline-none focus:ring-1 focus:ring-brand-500 ${
                  isDarkMode ? 'bg-slate-950 border-slate-850 text-white placeholder-slate-700' : 'bg-slate-50 border-slate-200 placeholder-slate-400'
                }`}
              />
            </div>

            {/* Grand Total Representation */}
            <div className="flex flex-col items-end shrink-0 select-none">
              <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400">Total Items: {items.filter(i => i.name !== '').length}</span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-sm font-semibold text-slate-500">Grand Total:</span>
                <span className="text-3xl font-black font-mono text-emerald-600 dark:text-emerald-500">
                  ₹{(manualGrandTotal ? Number(manualGrandTotal) : grandTotal).toFixed(2)}
                </span>
              </div>
            </div>
          </div>

          {/* Payment & Tracking Control Panel */}
          <div className="mt-4 p-4 rounded-2xl border border-dashed border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/20 grid grid-cols-1 md:grid-cols-3 gap-4 no-print">
            {/* Bill Amount Editor */}
            <div>
              <label className="block text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1.5">
                Bill Amount (₹)
              </label>
              <input
                type="number"
                placeholder="0.00"
                value={manualGrandTotal}
                onChange={(e) => setManualGrandTotal(e.target.value)}
                className={`w-full px-3 py-1.5 rounded-xl border text-sm font-semibold font-mono focus:outline-none focus:ring-1 focus:ring-brand-500 ${
                  isDarkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-900'
                }`}
              />
              <p className="text-[10px] text-slate-400 mt-1">Calculated: ₹{grandTotal.toFixed(2)}</p>
            </div>

            {/* Payment Status Dropdown */}
            <div>
              <label className="block text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1.5">
                Payment Status
              </label>
              <div className="relative">
                <select
                  value={paymentStatus}
                  onChange={(e) => {
                    const status = e.target.value as 'paid' | 'unpaid' | 'partial';
                    setPaymentStatus(status);
                    if (status === 'paid' && !paymentDate) {
                      setPaymentDate(getTodayDateString());
                    }
                  }}
                  className={`w-full pl-3 pr-8 py-1.5 rounded-xl border text-sm font-semibold focus:outline-none focus:ring-1 focus:ring-brand-500 appearance-none cursor-pointer ${
                    isDarkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-900'
                  }`}
                >
                  <option value="paid">🟢 Paid</option>
                  <option value="unpaid">🔴 Unpaid</option>
                  <option value="partial">🟡 Partial</option>
                </select>
                <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none text-xs text-slate-400">
                  ▼
                </div>
              </div>
            </div>

            {/* Payment Date & Mark as Paid */}
            <div className="flex flex-col justify-between gap-2">
              <div>
                <label className="block text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1">
                  Payment Date
                </label>
                <input
                  type="date"
                  value={paymentDate}
                  onChange={(e) => setPaymentDate(e.target.value)}
                  disabled={paymentStatus === 'unpaid'}
                  className={`w-full px-3 py-1 rounded-xl border text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-brand-500 ${
                    paymentStatus === 'unpaid' ? 'opacity-50 cursor-not-allowed' : ''
                  } ${
                    isDarkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-900'
                  }`}
                />
              </div>

              {paymentStatus !== 'paid' && (
                <button
                  type="button"
                  onClick={() => handleMarkAsPaid()}
                  className="w-full py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-extrabold rounded-xl shadow-sm transition active:scale-95"
                >
                  Mark as Paid
                </button>
              )}
            </div>
          </div>

          {/* Primary Operations Actions Footer */}
          <div className="mt-6 pt-4 border-t dark:border-slate-800 flex flex-wrap gap-3 items-center justify-between no-print">
            <div className="flex items-center gap-2">
              <button
                onClick={handlePrint}
                className={`inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                  isDarkMode 
                    ? 'border-slate-800 hover:bg-slate-800 text-slate-200' 
                    : 'border-slate-200 hover:bg-slate-50 text-slate-800'
                }`}
              >
                <Printer className="w-4 h-4 text-cyan-500" /> Print / PDF
              </button>

              <button
                onClick={handleWhatsAppShare}
                className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl border border-emerald-500/20 bg-emerald-500/5 text-emerald-500 hover:bg-emerald-500/10 text-xs font-bold transition-all cursor-pointer"
              >
                <Share2 className="w-4 h-4 text-emerald-500" /> WhatsApp
              </button>
            </div>

            {/* Save indicator / Save Button */}
            <div className="flex items-center gap-2">
              <AnimatePresence>
                {saveSuccess && (
                  <motion.span
                    initial={{ opacity: 0, x: 10 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0 }}
                    className="text-xs font-semibold text-emerald-500 flex items-center gap-1"
                  >
                    <Sparkles className="w-3.5 h-3.5 fill-emerald-500" /> Saved to cloud!
                  </motion.span>
                )}
              </AnimatePresence>

              <button
                onClick={handleSaveBill}
                disabled={saving}
                className="inline-flex items-center gap-1.5 px-6 py-2.5 bg-gradient-to-r from-brand-600 to-emerald-500 hover:from-brand-700 hover:to-emerald-600 text-white text-xs font-bold rounded-xl shadow-md transition-all cursor-pointer disabled:opacity-50"
              >
                <Save className="w-4 h-4" /> {saving ? 'Saving...' : selectedBillId ? 'Update Bill' : 'Save Bill'}
              </button>
            </div>
          </div>

        </div>
      </div>

      {/* RIGHT COMPONENT: Bill List / History Panel */}
      <div className="w-full lg:w-80 shrink-0 flex flex-col no-print">
        <h3 className="font-extrabold text-sm uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-1.5">
          <History className="w-4 h-4 text-brand-500" />
          Ledger History
        </h3>

        {/* History Filter Bar */}
        <div className="flex gap-1 mb-3 bg-slate-100 dark:bg-slate-950 p-1 rounded-2xl">
          {(['all', 'paid', 'unpaid', 'partial'] as const).map((filter) => (
            <button
              key={filter}
              onClick={() => setHistoryFilter(filter)}
              className={`flex-1 py-1 text-[10px] font-bold capitalize rounded-xl transition ${
                historyFilter === filter
                  ? 'bg-white dark:bg-slate-800 text-brand-600 dark:text-brand-400 shadow-sm'
                  : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
              }`}
            >
              {filter}
            </button>
          ))}
        </div>

        <div className={`p-4 rounded-3xl border shadow-md flex-1 overflow-hidden flex flex-col ${
          isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100'
        }`}>
          
          {historyLoading ? (
            <div className="py-12 text-center text-xs text-slate-500">
              <svg className="animate-spin h-5 w-5 text-brand-500 mx-auto mb-2" viewBox="0 0 24 24" fill="none">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
              </svg>
              Loading billing logs...
            </div>
          ) : billsHistory.length === 0 ? (
            <div className="py-12 text-center text-xs text-slate-500 flex-1 flex flex-col items-center justify-center">
              <FileText className="w-10 h-10 text-slate-300 dark:text-slate-700 mb-2 stroke-[1.5]" />
              <p className="font-semibold text-slate-400">No bills recorded yet</p>
              <p className="text-[10px] text-slate-500 mt-1">Create and save your first bill above.</p>
            </div>
          ) : (
            <div className="space-y-5 overflow-y-auto flex-1 pr-1">
              {(() => {
                const todayStr = getTodayDateString();
                const yesterday = new Date();
                yesterday.setDate(yesterday.getDate() - 1);
                const yesterdayStr = yesterday.toISOString().split('T')[0];

                const filteredBills = billsHistory.filter((b) => {
                  if (historyFilter === 'all') return true;
                  return (b.paymentStatus || 'unpaid') === historyFilter;
                });

                if (filteredBills.length === 0) {
                  return (
                    <div className="py-12 text-center text-xs text-slate-400">
                      No {historyFilter} bills found
                    </div>
                  );
                }

                const todayBills = filteredBills.filter((b) => b.date === todayStr);
                const yesterdayBills = filteredBills.filter((b) => b.date === yesterdayStr);
                const olderBills = filteredBills.filter((b) => b.date !== todayStr && b.date !== yesterdayStr);

                const renderBillCard = (bill: Bill) => {
                  const isActive = selectedBillId === bill.id;
                  const status = bill.paymentStatus || 'unpaid';
                  return (
                    <button
                      key={bill.id}
                      onClick={() => loadOldBill(bill)}
                      className={`w-full text-left p-3 rounded-xl border transition-all flex justify-between items-center ${
                        isActive
                          ? 'border-brand-500 bg-brand-500/5 text-brand-500 shadow-sm'
                          : isDarkMode
                            ? 'border-slate-850 hover:bg-slate-800 text-white'
                            : 'border-slate-100 hover:bg-slate-50 text-slate-900'
                      }`}
                    >
                      <div className="flex-1 min-w-0 pr-2">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${
                            isActive 
                              ? 'bg-brand-500/20 text-brand-600 dark:text-brand-400' 
                              : isDarkMode ? 'bg-slate-800 text-slate-300' : 'bg-slate-100 text-slate-600'
                          }`}>
                            {getRelativeDateLabel(bill.date)}
                          </span>
                          
                          <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-md ${
                            status === 'paid'
                              ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
                              : status === 'partial'
                                ? 'bg-amber-500/10 text-amber-600 dark:text-amber-400'
                                : 'bg-red-500/10 text-red-600 dark:text-red-400'
                          }`}>
                            {status === 'paid' ? '🟢 Paid' : status === 'partial' ? '🟡 Partial' : '🔴 Unpaid'}
                          </span>
                        </div>
                        <p className="text-[9px] font-mono text-slate-400 mt-1 uppercase flex items-center justify-between">
                          <span>ID: {bill.id.slice(0, 6)}</span>
                          {bill.paymentDate && (
                            <span className="text-[8px]">Paid: {bill.paymentDate}</span>
                          )}
                        </p>
                        <p className="text-[10px] text-slate-500 mt-0.5">{bill.items.length} item(s)</p>
                      </div>
                      <div className="text-right shrink-0 flex flex-col items-end">
                        <span className="text-xs font-extrabold font-mono text-emerald-600 dark:text-emerald-500">
                          ₹{bill.grandTotal.toFixed(2)}
                        </span>
                        {status !== 'paid' && (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleMarkAsPaid(bill.id);
                            }}
                            className="mt-1.5 px-2 py-0.5 bg-emerald-600 hover:bg-emerald-700 text-white text-[9px] font-black rounded shadow-sm transition active:scale-95"
                          >
                            Mark Paid
                          </button>
                        )}
                        {bill.notes && (
                          <p className="text-[8px] text-slate-400 italic mt-0.5 max-w-[80px] truncate">
                            {bill.notes}
                          </p>
                        )}
                      </div>
                    </button>
                  );
                };

                return (
                  <div className="space-y-4">
                    {todayBills.length > 0 && (
                      <div className="space-y-2">
                        <h4 className="text-[10px] font-extrabold uppercase tracking-widest text-brand-500 border-b border-slate-100 dark:border-slate-800 pb-1">Today's Bills</h4>
                        <div className="space-y-2">{todayBills.map(renderBillCard)}</div>
                      </div>
                    )}
                    {yesterdayBills.length > 0 && (
                      <div className="space-y-2">
                        <h4 className="text-[10px] font-extrabold uppercase tracking-widest text-amber-500 border-b border-slate-100 dark:border-slate-800 pb-1">Yesterday's Bills</h4>
                        <div className="space-y-2">{yesterdayBills.map(renderBillCard)}</div>
                      </div>
                    )}
                    {olderBills.length > 0 && (
                      <div className="space-y-2">
                        <h4 className="text-[10px] font-extrabold uppercase tracking-widest text-slate-400 border-b border-slate-100 dark:border-slate-800 pb-1">Older Bills</h4>
                        <div className="space-y-2">{olderBills.map(renderBillCard)}</div>
                      </div>
                    )}
                  </div>
                );
              })()}
            </div>
          )}
        </div>
      </div>

      {/* PRINT-ONLY COMPONENT (Completely styled like a real paper cash memo) */}
      <div className="print-only print-card text-black font-mono w-full text-xs leading-relaxed p-6">
        <div className="text-center mb-6">
          <h2 className="text-xl font-bold uppercase tracking-wider">
            {businessProfile?.businessName || 'TS BILL BOOK STORE'}
          </h2>
          <p className="text-[10px]">{businessProfile?.businessAddress || 'Main Bazar Road, Sector 2'}</p>
          <p className="text-[10px]">Contact: {businessProfile?.businessPhone || businessProfile?.phoneNumber || '9876543210'}</p>
          <div className="border-t border-black my-2" />
          <h3 className="text-sm font-bold uppercase">CASH MEMO / INVOICE</h3>
        </div>

        <div className="space-y-1 mb-4 text-[10px]">
          <div className="flex justify-between">
            <span>CUSTOMER: {shopkeeper.name.toUpperCase()}</span>
            <span>DATE: {billDate}</span>
          </div>
          <div className="flex justify-between">
            <span>CATEGORY: {shopkeeper.category.toUpperCase()}</span>
            <span>BILL ID: #{selectedBillId ? selectedBillId.toUpperCase().slice(0, 8) : 'TEMP-BILL'}</span>
          </div>
          <div className="flex justify-between font-bold">
            <span>STATUS: {(paymentStatus || 'unpaid').toUpperCase()}</span>
            {paymentDate && <span>PAYMENT DATE: {paymentDate}</span>}
          </div>
          {shopkeeper.phone && (
            <div>PHONE: +91 {shopkeeper.phone}</div>
          )}
        </div>

        <table className="w-full text-left border-t border-b border-black text-[10px]">
          <thead>
            <tr className="border-b border-black font-bold">
              <th className="py-1 w-8">#</th>
              <th className="py-1">ITEM DESCRIPTION</th>
              <th className="py-1 w-12 text-center">QTY</th>
              <th className="py-1 w-12 text-center">UNIT</th>
              <th className="py-1 w-16 text-right">RATE</th>
              <th className="py-1 w-20 text-right">TOTAL</th>
            </tr>
          </thead>
          <tbody>
            {items.filter(item => item.name.trim() !== '').map((item, index) => (
              <tr key={item.id} className="border-b border-dashed border-gray-400">
                <td className="py-1">{index + 1}</td>
                <td className="py-1">{item.name.toUpperCase()}</td>
                <td className="py-1 text-center">{item.quantity}</td>
                <td className="py-1 text-center">{item.pieces}</td>
                <td className="py-1 text-right">₹{item.price.toFixed(2)}</td>
                <td className="py-1 text-right">₹{item.total.toFixed(2)}</td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className="mt-4 space-y-1 text-right text-[10px]">
          <div className="flex justify-between font-bold border-b border-black pb-1">
            <span>TOTAL ITEMS IN MEMO:</span>
            <span>{items.filter(i => i.name !== '').length}</span>
          </div>
          <div className="flex justify-between text-sm font-black pt-1">
            <span>GRAND TOTAL DUE:</span>
            <span>₹{(manualGrandTotal ? Number(manualGrandTotal) : grandTotal).toFixed(2)}</span>
          </div>
        </div>

        {notes && (
          <div className="mt-4 border border-dashed border-black p-2 text-[10px]">
            <span className="font-bold block">REMARKS:</span>
            {notes.toUpperCase()}
          </div>
        )}

        <div className="mt-8 text-center text-[9px] border-t border-black pt-4">
          <p>POWERED BY: TS BILL BOOK PWA</p>
          <p>THANK YOU! VISIT AGAIN.</p>
        </div>
      </div>

      {/* AI PRODUCT SCANNER MODAL */}
      <CameraScanModal
        isOpen={isScanModalOpen}
        onClose={() => setIsScanModalOpen(false)}
        isDarkMode={isDarkMode}
        onProductDetected={handleProductScanComplete}
      />

      {/* DELETE CONFIRM POPUP (MODAL) */}
      <AnimatePresence>
        {deleteConfirmId && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setDeleteConfirmId(null)}
              className="fixed inset-0 bg-slate-950/60 backdrop-blur-sm"
            />
            
            <motion.div
              initial={{ scale: 0.95, y: 15, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.95, y: 15, opacity: 0 }}
              className={`relative w-full max-w-sm rounded-3xl p-6 shadow-2xl border z-10 transition-all ${
                isDarkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-100 text-slate-900'
              }`}
            >
              <div className="flex items-center gap-3 mb-4 text-red-500">
                <div className="p-2.5 bg-red-500/10 rounded-2xl">
                  <AlertTriangle className="w-6 h-6 shrink-0" />
                </div>
                <div>
                  <h4 className="font-extrabold text-base">Delete Invoice?</h4>
                  <p className="text-xs text-slate-500 mt-0.5">This action is irreversible.</p>
                </div>
              </div>

              <p className="text-xs text-slate-400 leading-relaxed mb-6">
                Are you absolutely sure you want to delete this invoice record from the digital database?
              </p>

              <div className="flex gap-3 justify-end">
                <button
                  type="button"
                  onClick={() => setDeleteConfirmId(null)}
                  className={`px-4 py-2 text-xs font-bold rounded-xl border transition ${
                    isDarkMode 
                      ? 'border-slate-800 hover:bg-slate-800 text-slate-300' 
                      : 'border-slate-200 hover:bg-slate-100 text-slate-600'
                  }`}
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleDeleteBill}
                  className="px-4 py-2 text-xs font-bold text-white bg-red-600 hover:bg-red-700 rounded-xl shadow-md transition"
                >
                  Delete Confirm
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
