import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Camera, Upload, X, Sparkles, AlertCircle, Check, RotateCcw, HelpCircle } from 'lucide-react';

interface CameraScanModalProps {
  isOpen: boolean;
  onClose: () => void;
  isDarkMode: boolean;
  onProductDetected: (product: { name: string; quantity: number; pieces: string; price: number }) => void;
}

export default function CameraScanModal({ isOpen, onClose, isDarkMode, onProductDetected }: CameraScanModalProps) {
  const [activeTab, setActiveTab] = useState<'camera' | 'upload'>('camera');
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [scanning, setScanning] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);

  // AI Result Form States
  const [aiResult, setAiResult] = useState<{
    productName: string;
    confidence: number;
    suggestedUnit: string;
  } | null>(null);

  const [editableName, setEditableName] = useState('');
  const [editableQty, setEditableQty] = useState(1);
  const [editableUnit, setEditableUnit] = useState('pcs');
  const [editablePrice, setEditablePrice] = useState(0);

  const videoRef = useRef<HTMLVideoElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const UNITS = ['pcs', 'kg', 'box', 'pkt', 'ltr', 'bags', 'g', 'dz'];

  // Start Camera Stream
  const startCamera = async () => {
    setCameraError(null);
    try {
      if (cameraStream) {
        cameraStream.getTracks().forEach(track => track.stop());
      }
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' },
        audio: false
      });
      setCameraStream(stream);
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err: any) {
      console.error('Error accessing camera:', err);
      setCameraError('Unable to access camera. Please allow camera permissions or use the Upload tab.');
      setActiveTab('upload');
    }
  };

  // Stop Camera Stream
  const stopCamera = () => {
    if (cameraStream) {
      cameraStream.getTracks().forEach(track => track.stop());
      setCameraStream(null);
    }
  };

  useEffect(() => {
    if (isOpen) {
      setCapturedImage(null);
      setAiResult(null);
      setError(null);
      setScanning(false);
      if (activeTab === 'camera') {
        startCamera();
      }
    } else {
      stopCamera();
    }
    return () => {
      stopCamera();
    };
  }, [isOpen, activeTab]);

  // Capture Image from live Video Element
  const capturePhoto = () => {
    if (videoRef.current) {
      const video = videoRef.current;
      const canvas = document.createElement('canvas');
      canvas.width = video.videoWidth || 640;
      canvas.height = video.videoHeight || 480;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
        setCapturedImage(dataUrl);
        stopCamera();
        analyzeProductImage(dataUrl);
      }
    }
  };

  // Handle local File Upload
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        const dataUrl = reader.result as string;
        setCapturedImage(dataUrl);
        analyzeProductImage(dataUrl);
      };
      reader.readAsDataURL(file);
    }
  };

  // Run the Product Analysis via backend Express route (using server-side Gemini 3.5 Flash)
  const analyzeProductImage = async (base64Image: string) => {
    setScanning(true);
    setError(null);
    setAiResult(null);
    try {
      const response = await fetch('/api/gemini/analyze-product', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ image: base64Image }),
      });

      if (!response.ok) {
        const errJson = await response.json();
        throw new Error(errJson.error || 'Server error during scanning');
      }

      const data = await response.json();
      setAiResult(data);
      
      // Auto-fill editable states
      setEditableName(data.productName || '');
      setEditableUnit(data.suggestedUnit || 'pcs');
      setEditableQty(1);
      setEditablePrice(0); // Price is manually set by user
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Failed to analyze product. Please enter details manually.');
    } finally {
      setScanning(false);
    }
  };

  const resetScanner = () => {
    setCapturedImage(null);
    setAiResult(null);
    setError(null);
    setScanning(false);
    if (activeTab === 'camera') {
      startCamera();
    }
  };

  const handleConfirmAndAdd = () => {
    if (!editableName.trim()) {
      alert('Please provide an item name.');
      return;
    }
    onProductDetected({
      name: editableName,
      quantity: Number(editableQty) || 1,
      pieces: editableUnit,
      price: Number(editablePrice) || 0
    });
    onClose();
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        {/* Backdrop overlay */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-slate-950/70 backdrop-blur-md"
        />

        {/* Modal Sheet */}
        <motion.div
          initial={{ scale: 0.95, y: 20, opacity: 0 }}
          animate={{ scale: 1, y: 0, opacity: 1 }}
          exit={{ scale: 0.95, y: 20, opacity: 0 }}
          transition={{ type: 'spring', damping: 25, stiffness: 250 }}
          className={`relative w-full max-w-lg rounded-3xl overflow-hidden shadow-2xl border z-10 flex flex-col max-h-[90vh] ${
            isDarkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-100 text-slate-900'
          }`}
        >
          {/* Header Panel */}
          <div className="p-5 border-b dark:border-slate-800 flex justify-between items-center bg-gradient-to-r from-purple-900/10 via-brand-500/10 to-emerald-500/10">
            <div className="flex items-center gap-2">
              <div className="p-2 bg-brand-500/15 rounded-xl text-brand-500">
                <Sparkles className="w-5 h-5 text-yellow-400 fill-yellow-400" />
              </div>
              <div>
                <h3 className="font-extrabold text-base">AI Camera Product Scan</h3>
                <p className="text-[10px] text-slate-500 dark:text-slate-400 font-medium">Capture or upload to instantly recognize product</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className={`p-1.5 rounded-full transition-all ${
                isDarkMode ? 'hover:bg-slate-800 text-slate-400' : 'hover:bg-slate-100 text-slate-500'
              }`}
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Body Content - Scrollable */}
          <div className="flex-1 overflow-y-auto p-5 space-y-4">
            {/* If no image captured yet, show camera view/upload selection */}
            {!capturedImage ? (
              <div className="space-y-4">
                {/* Custom Tab selectors */}
                <div className={`p-1 rounded-xl flex gap-1 ${isDarkMode ? 'bg-slate-950' : 'bg-slate-100'}`}>
                  <button
                    type="button"
                    onClick={() => setActiveTab('camera')}
                    className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 ${
                      activeTab === 'camera'
                        ? 'bg-brand-500 text-white shadow-sm'
                        : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
                    }`}
                  >
                    <Camera className="w-3.5 h-3.5" /> Direct Camera
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveTab('upload')}
                    className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 ${
                      activeTab === 'upload'
                        ? 'bg-brand-500 text-white shadow-sm'
                        : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
                    }`}
                  >
                    <Upload className="w-3.5 h-3.5" /> Upload / Gallery
                  </button>
                </div>

                {/* Tab content area */}
                {activeTab === 'camera' ? (
                  <div className="relative aspect-video rounded-2xl bg-black overflow-hidden flex flex-col items-center justify-center group shadow-md border border-slate-200 dark:border-slate-800">
                    {cameraError ? (
                      <div className="p-6 text-center text-xs text-red-400 flex flex-col items-center gap-2">
                        <AlertCircle className="w-8 h-8 text-red-500 animate-bounce" />
                        <p className="font-semibold">{cameraError}</p>
                      </div>
                    ) : (
                      <>
                        <video
                          ref={videoRef}
                          autoPlay
                          playsInline
                          className="w-full h-full object-cover transform scale-x-1"
                        />
                        {/* Shutter Overlay bar */}
                        <div className="absolute inset-x-0 bottom-0 p-4 bg-gradient-to-t from-black/80 to-transparent flex justify-center">
                          <button
                            type="button"
                            onClick={capturePhoto}
                            className="w-14 h-14 rounded-full border-4 border-white bg-red-600 hover:bg-red-700 transition active:scale-95 shadow-lg flex items-center justify-center cursor-pointer"
                          >
                            <div className="w-6 h-6 rounded-full bg-white animate-pulse" />
                          </button>
                        </div>
                      </>
                    )}
                  </div>
                ) : (
                  <div
                    onClick={() => fileInputRef.current?.click()}
                    className={`aspect-video rounded-2xl border-2 border-dashed flex flex-col items-center justify-center p-6 text-center cursor-pointer transition ${
                      isDarkMode 
                        ? 'border-slate-800 bg-slate-950/40 hover:bg-slate-950/80 hover:border-brand-500 text-slate-400' 
                        : 'border-slate-200 bg-slate-50/40 hover:bg-slate-50 hover:border-brand-500 text-slate-600'
                    }`}
                  >
                    <Upload className="w-10 h-10 text-slate-400 mb-3 stroke-[1.5]" />
                    <p className="text-xs font-bold">Select from gallery or snap a photo</p>
                    <p className="text-[10px] text-slate-400 mt-1">Supports JPEG, PNG up to 10MB</p>
                    
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      capture="environment"
                      onChange={handleFileChange}
                      className="hidden"
                    />
                  </div>
                )}
              </div>
            ) : (
              /* If photo is captured, show scanning visual or result form */
              <div className="space-y-4">
                {/* Selected Preview with visual scanning laser overlay */}
                <div className="relative aspect-video rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-black">
                  <img src={capturedImage} className="w-full h-full object-cover" alt="Captured product" />
                  
                  {/* Laser line overlay during scan */}
                  {scanning && (
                    <motion.div
                      initial={{ top: '0%' }}
                      animate={{ top: '100%' }}
                      transition={{
                        repeat: Infinity,
                        repeatType: 'reverse',
                        duration: 1.5,
                        ease: 'easeInOut'
                      }}
                      className="absolute left-0 right-0 h-1.5 bg-gradient-to-r from-transparent via-purple-500 to-transparent shadow-[0_0_8px_rgba(168,85,247,0.8)]"
                    />
                  )}

                  {/* Reset overlay button */}
                  {!scanning && (
                    <button
                      type="button"
                      onClick={resetScanner}
                      className="absolute top-2.5 right-2.5 bg-black/60 hover:bg-black/80 text-white rounded-xl px-3 py-1.5 text-[10px] font-bold flex items-center gap-1 transition"
                    >
                      <RotateCcw className="w-3.5 h-3.5" /> Retake
                    </button>
                  )}
                </div>

                {/* Loading / Scan state */}
                {scanning && (
                  <div className="py-4 text-center space-y-2">
                    <div className="inline-block relative w-8 h-8">
                      <div className="absolute inset-0 rounded-full border-4 border-brand-500/20 border-t-brand-500 animate-spin" />
                    </div>
                    <p className="text-xs font-bold text-brand-600 dark:text-brand-400 animate-pulse">Gemini AI is scanning the product...</p>
                    <p className="text-[10px] text-slate-500">Checking features, brand markings, and catalog details...</p>
                  </div>
                )}

                {/* Error handling */}
                {error && (
                  <div className="p-4 rounded-2xl bg-red-500/10 border border-red-500/20 text-red-500 text-xs flex gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                    <div>
                      <p className="font-bold">Scanning Failed</p>
                      <p className="mt-0.5 text-[10px] opacity-90">{error}</p>
                      <button
                        type="button"
                        onClick={() => {
                          setAiResult({ productName: '', confidence: 0, suggestedUnit: 'pcs' });
                          setEditableName('');
                          setError(null);
                        }}
                        className="mt-2 text-[10px] font-bold underline cursor-pointer hover:opacity-80 block"
                      >
                        Enter Product Name Manually
                      </button>
                    </div>
                  </div>
                )}

                {/* AI Scan Success form */}
                {aiResult && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-4"
                  >
                    {/* Confidence Match Indicator */}
                    <div className={`p-4.5 rounded-2xl border flex items-center justify-between gap-3 ${
                      aiResult.confidence >= 0.4
                        ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-600 dark:text-emerald-400'
                        : 'bg-yellow-500/10 border-yellow-500/20 text-yellow-600 dark:text-yellow-400'
                    }`}>
                      <div className="flex items-center gap-2">
                        {aiResult.confidence >= 0.4 ? (
                          <Check className="w-5 h-5 shrink-0" />
                        ) : (
                          <HelpCircle className="w-5 h-5 shrink-0" />
                        )}
                        <div>
                          <p className="text-xs font-bold">
                            {aiResult.confidence >= 0.4 
                              ? `AI Recognized! (${Math.round(aiResult.confidence * 100)}% Match)` 
                              : 'AI is unsure of the exact product'}
                          </p>
                          <p className="text-[10px] opacity-90 mt-0.5">
                            {aiResult.confidence >= 0.4 
                              ? 'Automatically identified product details.' 
                              : '“Please enter item name manually” to be sure.'}
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Editable Fields form */}
                    <div className="space-y-3.5 border-t dark:border-slate-800 pt-4">
                      {/* Name */}
                      <div>
                        <label className="block text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1">
                          Product / Item Name
                        </label>
                        <input
                          type="text"
                          placeholder="Please enter item name manually"
                          value={editableName}
                          onChange={(e) => setEditableName(e.target.value)}
                          className={`w-full px-3 py-2 rounded-xl border text-sm font-semibold focus:outline-none focus:ring-1 focus:ring-brand-500 ${
                            isDarkMode ? 'bg-slate-950 border-slate-850 text-white' : 'bg-slate-50 border-slate-200 text-slate-900'
                          }`}
                        />
                      </div>

                      {/* Qty, Unit, Price layout */}
                      <div className="grid grid-cols-3 gap-3">
                        {/* Quantity */}
                        <div>
                          <label className="block text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1">
                            Quantity
                          </label>
                          <input
                            type="number"
                            min={1}
                            value={editableQty}
                            onChange={(e) => setEditableQty(Number(e.target.value))}
                            className={`w-full px-3 py-2 rounded-xl border text-sm font-semibold text-center focus:outline-none focus:ring-1 focus:ring-brand-500 ${
                              isDarkMode ? 'bg-slate-950 border-slate-850 text-white' : 'bg-slate-50 border-slate-200 text-slate-900'
                            }`}
                          />
                        </div>

                        {/* Pieces / Unit */}
                        <div>
                          <label className="block text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1">
                            Pieces (Unit)
                          </label>
                          <select
                            value={editableUnit}
                            onChange={(e) => setEditableUnit(e.target.value)}
                            className={`w-full px-2 py-2 rounded-xl border text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-brand-500 cursor-pointer ${
                              isDarkMode ? 'bg-slate-950 border-slate-850 text-white' : 'bg-slate-50 border-slate-200 text-slate-900'
                            }`}
                          >
                            {UNITS.map(u => (
                              <option key={u} value={u}>{u}</option>
                            ))}
                          </select>
                        </div>

                        {/* Price */}
                        <div>
                          <label className="block text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1">
                            Price (₹)
                          </label>
                          <input
                            type="number"
                            min={0}
                            placeholder="0"
                            value={editablePrice === 0 ? '' : editablePrice}
                            onChange={(e) => setEditablePrice(Number(e.target.value))}
                            className={`w-full px-3 py-2 rounded-xl border text-sm font-semibold text-right focus:outline-none focus:ring-1 focus:ring-brand-500 ${
                              isDarkMode ? 'bg-slate-950 border-slate-850 text-white' : 'bg-slate-50 border-slate-200 text-slate-900'
                            }`}
                          />
                        </div>
                      </div>
                    </div>

                    {/* Action button */}
                    <div className="flex gap-3 pt-3">
                      <button
                        type="button"
                        onClick={resetScanner}
                        className={`flex-1 py-3 text-xs font-bold rounded-2xl border transition ${
                          isDarkMode 
                            ? 'border-slate-800 hover:bg-slate-800 text-slate-300' 
                            : 'border-slate-200 hover:bg-slate-100 text-slate-600'
                        }`}
                      >
                        Retake Photo
                      </button>

                      <button
                        type="button"
                        onClick={handleConfirmAndAdd}
                        className="flex-1 py-3 bg-gradient-to-r from-brand-600 to-emerald-500 hover:from-brand-700 hover:to-emerald-600 text-white text-xs font-bold rounded-2xl shadow-lg transition"
                      >
                        Add to Bill Table
                      </button>
                    </div>
                  </motion.div>
                )}
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
