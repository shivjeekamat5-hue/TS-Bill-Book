import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Menu, 
  X, 
  Search, 
  Store, 
  Plus, 
  Phone, 
  MapPin, 
  TrendingUp, 
  FileText, 
  LogOut, 
  Sun, 
  Moon, 
  ChevronRight, 
  Trash2, 
  Edit3, 
  Sparkles,
  Building,
  User,
  Users,
  Coins,
  AlertTriangle,
  Settings,
  Home,
  Smartphone,
  Download,
  Shield
} from 'lucide-react';
import { Shopkeeper, Bill, UserProfile } from '../types';
import { 
  getShopkeepers, 
  addShopkeeper, 
  updateShopkeeper, 
  deleteShopkeeper, 
  getBills, 
  auth,
  saveUserProfile
} from '../lib/firebase';
import ShopkeeperForm from './ShopkeeperForm';
import BillPage from './BillPage';
import AdminPanel from './AdminPanel';

interface DashboardProps {
  userId: string;
  isDarkMode: boolean;
  toggleDarkMode: () => void;
  onSignOut: () => void;
  userProfile: UserProfile | null;
  onProfileUpdate: (profile: UserProfile) => void;
  isInstallable?: boolean;
  onInstall?: () => Promise<void>;
}

export default function Dashboard({ 
  userId, 
  isDarkMode, 
  toggleDarkMode, 
  onSignOut, 
  userProfile, 
  onProfileUpdate,
  isInstallable,
  onInstall
}: DashboardProps) {
  // Navigation & UI States
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [selectedShopkeeper, setSelectedShopkeeper] = useState<Shopkeeper | null>(null);
  const [isAdminViewActive, setIsAdminViewActive] = useState(false);

  // Shopkeepers & Bills Data
  const [shopkeepers, setShopkeepers] = useState<Shopkeeper[]>([]);
  const [bills, setBills] = useState<Bill[]>([]);
  const [loading, setLoading] = useState(true);

  // First-Time Shop Name Popup State
  const [isFirstTimePopupOpen, setIsFirstTimePopupOpen] = useState(false);
  const [newShopName, setNewShopName] = useState('');
  const [popupSaving, setPopupSaving] = useState(false);

  // Settings Modal State
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [settingsShopName, setSettingsShopName] = useState('');
  const [settingsSaving, setSettingsSaving] = useState(false);

  // Monitor first-time entrance and sync states
  useEffect(() => {
    if (userProfile) {
      if (!userProfile.businessName) {
        setIsFirstTimePopupOpen(true);
      } else {
        setIsFirstTimePopupOpen(false);
      }
      setSettingsShopName(userProfile.businessName || '');
    }
  }, [userProfile]);

  // Enforce role-based access security on state change
  useEffect(() => {
    if (isAdminViewActive && userProfile?.role !== 'owner') {
      setIsAdminViewActive(false);
    }
  }, [isAdminViewActive, userProfile]);

  // Search & Filtering
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');

  // Modal Controllers
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingShopkeeper, setEditingShopkeeper] = useState<Shopkeeper | null>(null);
  
  // Custom delete shopkeeper confirmation state
  const [shopkeeperToDelete, setShopkeeperToDelete] = useState<Shopkeeper | null>(null);

  // Fetch all shopkeepers and bills
  const loadData = async () => {
    setLoading(true);
    try {
      const shopkeeperList = await getShopkeepers(userId);
      const billList = await getBills(userId);
      setShopkeepers(shopkeeperList);
      setBills(billList);
    } catch (err) {
      console.error('Error fetching data from Firestore:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [userId]);

  // Handle adding or editing a shopkeeper
  const handleSaveShopkeeper = async (data: Omit<Shopkeeper, 'id' | 'createdAt'>) => {
    if (editingShopkeeper) {
      await updateShopkeeper(userId, editingShopkeeper.id, data);
    } else {
      await addShopkeeper(userId, data);
    }
    await loadData();
    setIsFormOpen(false);
    setEditingShopkeeper(null);
  };

  // Handle deleting a shopkeeper
  const handleDeleteConfirm = async () => {
    if (!shopkeeperToDelete) return;
    try {
      await deleteShopkeeper(userId, shopkeeperToDelete.id);
      setShopkeeperToDelete(null);
      if (selectedShopkeeper?.id === shopkeeperToDelete.id) {
        setSelectedShopkeeper(null);
      }
      await loadData();
    } catch (err) {
      console.error('Error deleting customer:', err);
      alert('Failed to delete shopkeeper.');
    }
  };

  // Save first-time shop name
  const handleSaveFirstTimeShopName = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newShopName.trim()) return;
    setPopupSaving(true);
    try {
      const updatedProfile: UserProfile = {
        ...userProfile,
        uid: userId,
        email: userProfile?.email || '',
        businessName: newShopName.trim()
      };
      await saveUserProfile(userId, updatedProfile);
      onProfileUpdate(updatedProfile);
      setIsFirstTimePopupOpen(false);
    } catch (err) {
      console.error('Error saving first-time shop name:', err);
      alert('Failed to save shop name.');
    } finally {
      setPopupSaving(false);
    }
  };

  // Save edited settings shop name
  const handleSaveSettingsShopName = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!settingsShopName.trim()) return;
    setSettingsSaving(true);
    try {
      const updatedProfile: UserProfile = {
        ...userProfile,
        uid: userId,
        email: userProfile?.email || '',
        businessName: settingsShopName.trim()
      };
      await saveUserProfile(userId, updatedProfile);
      onProfileUpdate(updatedProfile);
      setIsSettingsOpen(false);
    } catch (err) {
      console.error('Error saving settings shop name:', err);
      alert('Failed to save settings.');
    } finally {
      setSettingsSaving(false);
    }
  };

  // Calculate stats for widgets
  const getTodayDateString = () => {
    const today = new Date();
    const offset = today.getTimezoneOffset();
    const localToday = new Date(today.getTime() - (offset * 60 * 1000));
    return localToday.toISOString().split('T')[0];
  };

  const todayStr = getTodayDateString();
  const todayBills = bills.filter(b => b.date === todayStr);
  const todayTotalSales = todayBills.reduce((sum, b) => sum + b.grandTotal, 0);

  // Payment Stats
  const totalBillsCount = bills.length;
  const totalPaidAmount = bills.filter(b => b.paymentStatus === 'paid').reduce((sum, b) => sum + b.grandTotal, 0);
  const totalPendingAmount = bills.filter(b => b.paymentStatus !== 'paid').reduce((sum, b) => sum + b.grandTotal, 0);

  // Filter shopkeepers based on search query and category
  const filteredShopkeepers = shopkeepers.filter(sk => {
    const matchesSearch = sk.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          (sk.phone && sk.phone.includes(searchQuery));
    const matchesCategory = selectedCategory === 'All' || sk.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const categories = ['All', 'Kirana Store', 'Medical Store', 'Vegetable Seller', 'General Store'];

  // Handle signout
  const handleSignOutClick = () => {
    auth.signOut();
    onSignOut();
  };

  return (
    <div className={`min-h-screen flex flex-col ${isDarkMode ? 'bg-slate-950 text-white' : 'bg-slate-50 text-slate-900'}`}>
      
      {/* 1. TOP HEADER BAR */}
      <header className={`sticky top-0 z-30 px-4 md:px-6 py-3 border-b flex justify-between items-center no-print ${
        isDarkMode ? 'bg-slate-900/90 border-slate-800' : 'bg-white/90 border-slate-100'
      } backdrop-blur-md`}>
        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsSidebarOpen(true)}
            className="p-1.5 rounded-xl hover:bg-slate-200 dark:hover:bg-slate-800 transition lg:hidden"
            title="Open side menu"
          >
            <Menu className="w-5 h-5" />
          </button>
          
          <div className="flex items-center gap-2 select-none">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-brand-600 to-emerald-400 flex items-center justify-center text-white font-black shadow-md shadow-emerald-500/10">
              TS
            </div>
            <div>
              <h1 className="font-black text-sm tracking-tight leading-none bg-gradient-to-r from-slate-900 via-slate-800 to-emerald-500 dark:from-white dark:via-slate-200 dark:to-emerald-400 bg-clip-text text-transparent">
                TS Bill Book
              </h1>
              <span className="text-[9px] font-mono tracking-widest text-slate-400 dark:text-slate-500 uppercase leading-none mt-0.5 block">
                Digital Ledger
              </span>
            </div>
          </div>
        </div>

        {/* Global Action Rails */}
        <div className="flex items-center gap-2">
          {/* Home / Dashboard button */}
          <button
            onClick={() => setSelectedShopkeeper(null)}
            className={`p-2 rounded-xl transition ${
              selectedShopkeeper === null
                ? 'bg-brand-500 text-white shadow-sm shadow-brand-500/20'
                : isDarkMode ? 'hover:bg-slate-800 text-slate-300' : 'hover:bg-slate-100 text-slate-600'
            }`}
            title="Dashboard"
          >
            <Home className="w-4 h-4" />
          </button>

          {/* Dark Mode toggle */}
          <button
            onClick={toggleDarkMode}
            className={`p-2 rounded-xl transition ${
              isDarkMode ? 'hover:bg-slate-800 text-yellow-400' : 'hover:bg-slate-100 text-slate-600'
            }`}
            title="Toggle theme"
          >
            {isDarkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>

          {/* Admin Panel button (only for shivjeekamat5@gmail.com owner) */}
          {userProfile?.role === 'owner' && (
            <button
              onClick={() => {
                setSelectedShopkeeper(null);
                setIsAdminViewActive(true);
              }}
              className={`p-2 rounded-xl transition ${
                isAdminViewActive
                  ? 'bg-emerald-500 text-slate-950 shadow-sm shadow-emerald-500/20'
                  : isDarkMode ? 'hover:bg-slate-800 text-slate-300' : 'hover:bg-slate-100 text-slate-600'
              }`}
              title="Super Admin Panel"
            >
              <Shield className="w-4 h-4" />
            </button>
          )}

          {/* Settings button */}
          <button
            onClick={() => {
              setSettingsShopName(userProfile?.businessName || '');
              setIsSettingsOpen(true);
            }}
            className={`p-2 rounded-xl transition ${
              isDarkMode ? 'hover:bg-slate-800 text-slate-300' : 'hover:bg-slate-100 text-slate-600'
            }`}
            title="Settings"
          >
            <Settings className="w-4 h-4" />
          </button>

          {/* User business name / email */}
          <div className="hidden sm:flex flex-col text-right mr-2 select-none">
            <span className="text-xs font-extrabold text-brand-600 dark:text-brand-500 max-w-[150px] truncate">
              {userProfile?.businessName || 'My Ledger Book'}
            </span>
            <span className="text-[9px] font-mono text-slate-400 truncate max-w-[150px]">
              {userProfile?.email}
            </span>
          </div>

          {/* Sign Out Button */}
          <button
            onClick={handleSignOutClick}
            className="p-2 rounded-xl hover:bg-red-500/10 text-slate-400 hover:text-red-500 transition"
            title="Sign Out"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </header>

      <div className="flex-1 flex overflow-hidden">
        
        {/* 2. SIDEBAR DRAWER (Responsive: slide in on mobile, static on desktop) */}
        <AnimatePresence>
          {(isSidebarOpen || window.innerWidth >= 1024) && (
            <>
              {/* Backdrop for mobile */}
              {isSidebarOpen && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  onClick={() => setIsSidebarOpen(false)}
                  className="fixed inset-0 bg-slate-950/40 backdrop-blur-sm z-40 lg:hidden"
                />
              )}

              {/* Sidebar container */}
              <motion.aside
                initial={window.innerWidth < 1024 ? { x: -300 } : false}
                animate={window.innerWidth < 1024 ? { x: 0 } : false}
                exit={window.innerWidth < 1024 ? { x: -300 } : false}
                transition={{ type: 'spring', damping: 25, stiffness: 220 }}
                className={`fixed inset-y-0 left-0 w-72 lg:static shrink-0 border-r z-40 lg:z-10 flex flex-col no-print ${
                  isDarkMode ? 'bg-slate-900/95 border-slate-800' : 'bg-white border-slate-100'
                }`}
              >
                {/* Header inside sidebar (mobile-only) */}
                <div className="p-4 border-b dark:border-slate-800 flex justify-between items-center lg:hidden">
                  <span className="font-extrabold text-sm uppercase text-slate-500 tracking-wider">Shopkeepers Menu</span>
                  <button
                    onClick={() => setIsSidebarOpen(false)}
                    className="p-1.5 rounded-full hover:bg-slate-200 dark:hover:bg-slate-800 transition"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                 {/* Dashboard Menu Item */}
                <div className="px-4 pt-4 pb-0">
                  <button
                    onClick={() => {
                      setSelectedShopkeeper(null);
                      setIsAdminViewActive(false);
                      setIsSidebarOpen(false); // Close sidebar on mobile
                    }}
                    className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-2xl font-extrabold text-xs tracking-wider uppercase transition-all duration-200 cursor-pointer ${
                      selectedShopkeeper === null && !isAdminViewActive
                        ? 'bg-brand-500 text-slate-950 shadow-lg shadow-brand-500/20'
                        : isDarkMode
                          ? 'text-slate-300 hover:bg-slate-850 hover:text-white'
                          : 'text-slate-700 hover:bg-slate-100 hover:text-slate-900'
                    }`}
                  >
                    <Home className="w-4 h-4 shrink-0" />
                    <span>Dashboard Home</span>
                  </button>
                </div>

                {/* Admin Panel Sidebar Menu Item */}
                {userProfile?.role === 'owner' && (
                  <div className="px-4 pt-2 pb-0">
                    <button
                      onClick={() => {
                        setSelectedShopkeeper(null);
                        setIsAdminViewActive(true);
                        setIsSidebarOpen(false); // Close sidebar on mobile
                      }}
                      className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-2xl font-extrabold text-xs tracking-wider uppercase transition-all duration-200 cursor-pointer ${
                        isAdminViewActive
                          ? 'bg-emerald-500 text-slate-950 shadow-lg shadow-emerald-500/20'
                          : isDarkMode
                            ? 'text-slate-300 hover:bg-slate-850 hover:text-white'
                            : 'text-slate-700 hover:bg-slate-100 hover:text-slate-900'
                      }`}
                    >
                      <Shield className="w-4 h-4 shrink-0" />
                      <span>Admin Panel</span>
                    </button>
                  </div>
                )}

                {/* Customer Filter / Search */}
                <div className="p-4 space-y-3">
                  <div className="relative">
                    <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400">
                      <Search className="w-4 h-4" />
                    </span>
                    <input
                      type="text"
                      placeholder="Search shopkeeper..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className={`w-full pl-9 pr-3 py-2 rounded-xl border text-xs focus:outline-none focus:ring-1 focus:ring-brand-500 transition-colors ${
                        isDarkMode ? 'bg-slate-950 border-slate-800 text-white placeholder-slate-700' : 'bg-slate-50 border-slate-200 text-slate-900 placeholder-slate-400'
                      }`}
                    />
                  </div>

                  {/* Quick Category filter buttons */}
                  <div className="flex gap-1.5 overflow-x-auto pb-1 -mx-2 px-2 scrollbar-none">
                    {categories.map((cat) => (
                      <button
                        key={cat}
                        onClick={() => setSelectedCategory(cat)}
                        className={`px-2.5 py-1 text-[10px] font-bold rounded-lg shrink-0 transition ${
                          selectedCategory === cat
                            ? 'bg-brand-500 text-white shadow-sm shadow-brand-500/20'
                            : isDarkMode ? 'bg-slate-800 hover:bg-slate-750 text-slate-300' : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                        }`}
                      >
                        {cat === 'All' ? 'All' : cat.split(' ')[0]}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Shopkeepers List */}
                <div className="flex-1 overflow-y-auto px-2 space-y-1.5 pb-4">
                  <div className="px-2 py-1 flex justify-between items-center select-none">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                      Records ({filteredShopkeepers.length})
                    </span>
                    <button
                      onClick={() => {
                        setEditingShopkeeper(null);
                        setIsFormOpen(true);
                      }}
                      className="text-brand-500 hover:text-brand-600 text-xs font-bold flex items-center gap-0.5 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" /> Add
                    </button>
                  </div>

                  {loading ? (
                    <div className="py-8 text-center text-xs text-slate-500">
                      <svg className="animate-spin h-5 w-5 text-brand-500 mx-auto mb-2" viewBox="0 0 24 24" fill="none">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                      </svg>
                      Synchronizing...
                    </div>
                  ) : filteredShopkeepers.length === 0 ? (
                    <div className="py-8 text-center text-xs text-slate-500 italic">
                      No customer ledger found.
                    </div>
                  ) : (
                    filteredShopkeepers.map((sk) => {
                      const isSelected = selectedShopkeeper?.id === sk.id;
                      return (
                        <div
                          key={sk.id}
                          className={`group rounded-2xl border p-2.5 transition-all relative ${
                            isSelected
                              ? 'border-brand-500 bg-brand-500/5 shadow-sm'
                              : isDarkMode
                                ? 'border-slate-850 hover:bg-slate-800 text-white'
                                : 'border-slate-100 hover:bg-slate-100 text-slate-900'
                          }`}
                        >
                          {/* Main Clickable item info */}
                          <div
                            onClick={() => {
                              setSelectedShopkeeper(sk);
                              setIsSidebarOpen(false); // Close sidebar on mobile
                            }}
                            className="cursor-pointer pr-10"
                          >
                            <h4 className="font-extrabold text-xs tracking-tight line-clamp-1">{sk.name}</h4>
                            <div className="flex items-center gap-1.5 mt-1">
                              <span className={`text-[9px] px-1.5 py-0.5 rounded-full font-semibold ${
                                isDarkMode ? 'bg-slate-800 text-slate-400' : 'bg-slate-200 text-slate-600'
                              }`}>
                                {sk.category}
                              </span>
                              {sk.phone && (
                                <span className="text-[9px] text-slate-500 font-mono">{sk.phone}</span>
                              )}
                            </div>
                          </div>

                          {/* Quick Actions (Hover overlay or menu bar) */}
                          <div className="absolute right-2 top-2.5 flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                            <button
                              onClick={() => {
                                setEditingShopkeeper(sk);
                                setIsFormOpen(true);
                              }}
                              className="p-1 rounded-lg text-slate-400 hover:text-brand-500 hover:bg-slate-200 dark:hover:bg-slate-700 transition"
                              title="Edit shopkeeper"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => setShopkeeperToDelete(sk)}
                              className="p-1 rounded-lg text-slate-400 hover:text-red-500 hover:bg-slate-200 dark:hover:bg-slate-700 transition"
                              title="Delete shopkeeper"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>

                {/* Sidebar footer showing brand licensing */}
                <div className="p-4 border-t dark:border-slate-800 text-center select-none">
                  <span className="text-[10px] text-slate-500 font-mono">TS Bill Book v1.0.0</span>
                </div>
              </motion.aside>
            </>
          )}
        </AnimatePresence>

        {/* 3. MAIN WORKSPACE */}
        <main className="flex-1 overflow-y-auto">
          {isAdminViewActive && userProfile?.role === 'owner' ? (
            <AdminPanel
              isDarkMode={isDarkMode}
              onBack={() => setIsAdminViewActive(false)}
            />
          ) : selectedShopkeeper ? (
            <BillPage
              userId={userId}
              shopkeeper={selectedShopkeeper}
              onBack={() => {
                setSelectedShopkeeper(null);
                setIsAdminViewActive(false);
              }}
              isDarkMode={isDarkMode}
              businessProfile={userProfile}
            />
          ) : (
            /* DEFAULT DASHBOARD HOME SCREEN */
            <div className="p-4 md:p-6 max-w-4xl mx-auto space-y-6 no-print">
              
              {/* Profile Card / Welcome Hero */}
              <div className={`p-6 rounded-3xl border shadow-md flex flex-col md:flex-row md:items-center justify-between gap-4 ${
                isDarkMode ? 'bg-gradient-to-br from-slate-900 to-slate-950 border-slate-800' : 'bg-white border-slate-100'
              }`}>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-brand-500/10 text-brand-500 flex items-center justify-center shadow-inner">
                    <Building className="w-6 h-6 stroke-[2]" />
                  </div>
                  <div>
                    <span className="text-[9px] uppercase font-mono tracking-widest text-slate-400">Welcome back</span>
                    <h3 className="text-xl font-black">{userProfile?.businessName || 'TS Ledger Store'}</h3>
                    <p className="text-xs text-slate-500">Owner: {userProfile?.displayName || userProfile?.email?.split('@')[0]}</p>
                  </div>
                </div>

                <div className="text-left md:text-right font-mono">
                  <p className="text-xs text-slate-500">Billing Date (Today)</p>
                  <p className="text-base font-bold text-brand-600 dark:text-brand-500">
                    {new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'short', year: 'numeric' })}
                  </p>
                </div>
              </div>

              {/* PWA Install Promotion Card */}
              {isInstallable && onInstall && (
                <div className={`p-5 rounded-3xl border border-dashed flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-sm ${
                  isDarkMode 
                    ? 'border-brand-500/30 bg-brand-500/5 text-white' 
                    : 'border-brand-500/40 bg-brand-50/50 text-slate-900'
                }`}>
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-2xl bg-brand-500/10 text-brand-600 dark:text-brand-400 flex items-center justify-center shrink-0">
                      <Smartphone className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="font-extrabold text-sm flex items-center gap-1.5 text-brand-600 dark:text-brand-400">
                        Install TS Bill Book App <Sparkles className="w-3.5 h-3.5 text-yellow-500 fill-yellow-500" />
                      </h4>
                      <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                        Get our standalone app for offline ledger tracking, instant home screen launching & premium experience.
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={onInstall}
                    className="sm:self-center px-5 py-2.5 bg-brand-500 hover:bg-brand-600 text-slate-950 font-black text-xs rounded-xl shadow-md hover:shadow-brand-500/10 transition active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Download className="w-4 h-4 shrink-0 animate-pulse" />
                    Install App
                  </button>
                </div>
              )}

              {/* STATS BENTO GRID */}
              <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-5 gap-4">
                
                {/* 1. Total Bills */}
                <div className={`p-5 rounded-3xl border shadow-sm ${
                  isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100'
                }`}>
                  <div className="flex justify-between items-center mb-3">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Total Bills</span>
                    <FileText className="w-4 h-4 text-cyan-500" />
                  </div>
                  <h4 className="text-2xl font-black font-mono text-cyan-500">
                    {totalBillsCount}
                  </h4>
                  <p className="text-[10px] text-slate-500 mt-1">Recorded bills in system</p>
                </div>

                {/* 2. Total Paid Amount */}
                <div className={`p-5 rounded-3xl border shadow-sm ${
                  isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100'
                }`}>
                  <div className="flex justify-between items-center mb-3">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Total Paid</span>
                    <Coins className="w-4 h-4 text-emerald-500" />
                  </div>
                  <h4 className="text-2xl font-black font-mono text-emerald-600 dark:text-emerald-500">
                    ₹{totalPaidAmount.toFixed(2)}
                  </h4>
                  <p className="text-[10px] text-slate-500 mt-1">Settled invoices total</p>
                </div>

                {/* 3. Total Pending Amount */}
                <div className={`p-5 rounded-3xl border shadow-sm ${
                  isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100'
                }`}>
                  <div className="flex justify-between items-center mb-3">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Total Pending</span>
                    <AlertTriangle className="w-4 h-4 text-rose-500" />
                  </div>
                  <h4 className="text-2xl font-black font-mono text-rose-600 dark:text-rose-500">
                    ₹{totalPendingAmount.toFixed(2)}
                  </h4>
                  <p className="text-[10px] text-slate-500 mt-1">Unpaid/ledger dues</p>
                </div>

                {/* 4. Today sales */}
                <div className={`p-5 rounded-3xl border shadow-sm ${
                  isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100'
                }`}>
                  <div className="flex justify-between items-center mb-3">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Today's Sales</span>
                    <TrendingUp className="w-4 h-4 text-brand-500" />
                  </div>
                  <h4 className="text-2xl font-black font-mono text-brand-500">
                    ₹{todayTotalSales.toFixed(2)}
                  </h4>
                  <p className="text-[10px] text-slate-500 mt-1">{todayBills.length} bills generated today</p>
                </div>

                {/* 5. Customer lists count */}
                <div className={`p-5 rounded-3xl border shadow-sm sm:col-span-3 lg:col-span-1 ${
                  isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100'
                }`}>
                  <div className="flex justify-between items-center mb-3">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Store Customers</span>
                    <Users className="w-4 h-4 text-amber-500" />
                  </div>
                  <h4 className="text-2xl font-black font-mono text-amber-600 dark:text-amber-500">
                    {shopkeepers.length}
                  </h4>
                  <p className="text-[10px] text-slate-500 mt-1">Active ledger accounts</p>
                </div>

              </div>

              {/* QUICK RECENT BILLS LOGS */}
              <div className="space-y-3">
                <h3 className="font-extrabold text-sm uppercase tracking-wider text-slate-400 flex items-center gap-1.5 select-none">
                  <TrendingUp className="w-4 h-4 text-brand-500" />
                  Recent Ledger Transactions
                </h3>

                <div className={`border rounded-3xl overflow-hidden shadow-sm ${
                  isDarkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100'
                }`}>
                  {bills.length === 0 ? (
                    <div className="p-8 text-center text-xs text-slate-500 flex flex-col items-center justify-center">
                      <FileText className="w-12 h-12 text-slate-300 dark:text-slate-700 mb-2 stroke-[1.2]" />
                      <p className="font-bold">No Transactions Logged</p>
                      <p className="text-[10px] text-slate-400 mt-0.5">Choose a customer from the side list to issue invoices.</p>
                    </div>
                  ) : (
                    <div className="divide-y divide-slate-100 dark:divide-slate-800">
                      {bills.slice(0, 5).map((bill) => {
                        const targetShopkeeper = shopkeepers.find(sk => sk.id === bill.shopkeeperId);
                        return (
                          <div
                            key={bill.id}
                            onClick={() => {
                              if (targetShopkeeper) {
                                setSelectedShopkeeper(targetShopkeeper);
                              } else {
                                // Fallback shopkeeper container object to prevent errors
                                setSelectedShopkeeper({
                                  id: bill.shopkeeperId,
                                  name: bill.shopkeeperName,
                                  category: 'Unknown',
                                  phone: '',
                                  address: '',
                                  createdAt: ''
                                });
                              }
                            }}
                            className="p-4 hover:bg-slate-50 dark:hover:bg-slate-950/30 transition flex justify-between items-center cursor-pointer group"
                          >
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-slate-850 flex items-center justify-center">
                                <Store className="w-5 h-5 text-slate-400 group-hover:text-brand-500 transition" />
                              </div>
                              <div>
                                <h4 className="font-extrabold text-sm group-hover:text-brand-500 transition leading-snug">{bill.shopkeeperName}</h4>
                                <div className="flex items-center gap-1.5 mt-0.5 font-mono text-[9px] text-slate-500 flex-wrap">
                                  <span>{new Date(bill.date).toLocaleDateString('en-IN', { day: '2-digit', month: 'short' })}</span>
                                  <span>•</span>
                                  <span>{bill.items.length} item(s)</span>
                                  <span>•</span>
                                  <span className={`px-1 rounded-md text-[8px] font-bold ${
                                    (bill.paymentStatus || 'unpaid') === 'paid'
                                      ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
                                      : (bill.paymentStatus || 'unpaid') === 'partial'
                                        ? 'bg-amber-500/10 text-amber-600 dark:text-amber-400'
                                        : 'bg-red-500/10 text-red-600 dark:text-red-400'
                                  }`}>
                                    {((bill.paymentStatus || 'unpaid') === 'paid' ? '🟢 Paid' : (bill.paymentStatus || 'unpaid') === 'partial' ? '🟡 Partial' : '🔴 Unpaid')}
                                  </span>
                                </div>
                              </div>
                            </div>

                            <div className="flex items-center gap-2">
                              <div className="text-right">
                                <p className="font-mono text-sm font-black text-emerald-600 dark:text-emerald-500">₹{bill.grandTotal.toFixed(2)}</p>
                                {bill.notes && <p className="text-[9px] text-slate-400 italic max-w-[120px] truncate">{bill.notes}</p>}
                              </div>
                              <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-brand-500 group-hover:translate-x-0.5 transition" />
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>

              {/* QUICK STARTER TIPS */}
              <div className={`p-5 rounded-3xl border border-dashed text-slate-500 select-none ${
                isDarkMode ? 'border-slate-800 bg-slate-900/10' : 'border-slate-200 bg-slate-100/30'
              }`}>
                <h4 className="font-bold text-xs flex items-center gap-1 text-slate-700 dark:text-slate-300">
                  <Sparkles className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                  Quick Tutorial
                </h4>
                <ul className="list-disc pl-5 mt-2 space-y-1 text-xs">
                  <li>Select any shopkeeper on the left side-bar to record bills.</li>
                  <li>Invoices calculate prices dynamically inside item logs.</li>
                  <li>Press <strong>Add Item Line</strong> or Tab keys to add consecutive rows.</li>
                  <li>Click <strong>Print / PDF</strong> to save/download offline memo records.</li>
                </ul>
              </div>

            </div>
          )}
        </main>
      </div>

      {/* 4. MODALS AND FORM OVERLAYS */}
      
      {/* ADD/EDIT SHOPKEEPER MODAL */}
      <ShopkeeperForm
        isOpen={isFormOpen}
        onClose={() => {
          setIsFormOpen(false);
          setEditingShopkeeper(null);
        }}
        onSubmit={handleSaveShopkeeper}
        shopkeeper={editingShopkeeper}
        isDarkMode={isDarkMode}
      />

      {/* SHOPKEEPER DELETE DOUBLE-CONFIRM OVERLAY */}
      <AnimatePresence>
        {shopkeeperToDelete && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShopkeeperToDelete(null)}
              className="fixed inset-0 bg-slate-950/60 backdrop-blur-sm"
            />
            
            <motion.div
              initial={{ scale: 0.95, y: 15, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.95, y: 15, opacity: 0 }}
              className={`relative w-full max-w-sm rounded-3xl p-6 shadow-2xl border z-10 transition-all ${
                isDarkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-100 text-slate-900'
              }`}
            >
              <div className="flex items-center gap-3 mb-4 text-red-500">
                <div className="p-2.5 bg-red-500/10 rounded-2xl">
                  <AlertTriangle className="w-6 h-6 shrink-0" />
                </div>
                <div>
                  <h4 className="font-extrabold text-base">Delete Account?</h4>
                  <p className="text-xs text-slate-500 mt-0.5">This removes the customer.</p>
                </div>
              </div>

              <p className="text-xs text-slate-400 leading-relaxed mb-6">
                Are you absolutely sure you want to delete customer <strong>{shopkeeperToDelete.name}</strong>? Historical bills will remain intact but the account reference profile will be removed.
              </p>

              <div className="flex gap-3 justify-end">
                <button
                  type="button"
                  onClick={() => setShopkeeperToDelete(null)}
                  className={`px-4 py-2 text-xs font-bold rounded-xl border transition ${
                    isDarkMode 
                      ? 'border-slate-800 hover:bg-slate-800 text-slate-300' 
                      : 'border-slate-200 hover:bg-slate-100 text-slate-600'
                  }`}
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleDeleteConfirm}
                  className="px-4 py-2 text-xs font-bold text-white bg-red-600 hover:bg-red-700 rounded-xl shadow-md transition"
                >
                  Delete Confirm
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* FIRST-TIME SHOP NAME POPUP OVERLAY */}
      <AnimatePresence>
        {isFirstTimePopupOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-slate-950/70 backdrop-blur-md animate-none"
            />
            
            <motion.div
              initial={{ scale: 0.9, y: 20, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.9, y: 20, opacity: 0 }}
              className={`relative w-full max-w-md rounded-3xl p-6 md:p-8 shadow-2xl border z-10 transition-all ${
                isDarkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-100 text-slate-900'
              }`}
            >
              <div className="text-center mb-6 select-none">
                <div className="inline-flex items-center justify-center w-12 h-12 rounded-2xl bg-emerald-500/10 text-emerald-500 mb-3">
                  <Store className="w-6 h-6 text-brand-500" />
                </div>
                <h3 className="text-lg font-black">Enter Your Shop Name</h3>
                <p className="text-xs text-slate-500 mt-1">Please set your store branding before generating your first invoice</p>
              </div>

              <form onSubmit={handleSaveFirstTimeShopName} className="space-y-4">
                <div>
                  <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">Shop Name</label>
                  <input
                    type="text"
                    required
                    autoFocus
                    placeholder="e.g. TS Kirana Store"
                    value={newShopName}
                    onChange={(e) => setNewShopName(e.target.value)}
                    className={`w-full px-4 py-2.5 rounded-xl border text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-brand-500/20 focus:border-brand-500 transition-all ${
                      isDarkMode 
                        ? 'bg-slate-950 border-slate-800 text-white placeholder-slate-700' 
                        : 'bg-slate-50 border-slate-200 text-slate-950 placeholder-slate-400'
                    }`}
                  />
                </div>

                <button
                  type="submit"
                  disabled={popupSaving || !newShopName.trim()}
                  className="w-full inline-flex items-center justify-center px-4 py-3 rounded-xl shadow-lg shadow-emerald-500/10 text-sm font-bold text-white bg-gradient-to-r from-brand-600 to-emerald-500 hover:from-brand-700 hover:to-emerald-600 disabled:opacity-50 transition-all cursor-pointer border border-brand-400/15"
                >
                  {popupSaving ? 'Saving...' : 'Save & Enter Dashboard'}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* EDIT SETTINGS MODAL OVERLAY */}
      <AnimatePresence>
        {isSettingsOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsSettingsOpen(false)}
              className="fixed inset-0 bg-slate-950/50 backdrop-blur-sm"
            />
            
            <motion.div
              initial={{ scale: 0.95, y: 15, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.95, y: 15, opacity: 0 }}
              className={`relative w-full max-w-md rounded-3xl p-6 shadow-2xl border z-10 transition-all ${
                isDarkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-100 text-slate-900'
              }`}
            >
              <div className="flex justify-between items-center mb-6">
                <div className="flex items-center gap-2">
                  <div className="p-2 bg-brand-500/10 text-brand-600 rounded-xl">
                    <Settings className="w-5 h-5" />
                  </div>
                  <h3 className="font-extrabold text-base">Settings</h3>
                </div>
                <button
                  onClick={() => setIsSettingsOpen(false)}
                  className="p-1.5 rounded-full hover:bg-slate-200 dark:hover:bg-slate-800 transition text-slate-400 hover:text-slate-200"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form onSubmit={handleSaveSettingsShopName} className="space-y-4">
                <div>
                  <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">Shop Name</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. TS Kirana Store"
                    value={settingsShopName}
                    onChange={(e) => setSettingsShopName(e.target.value)}
                    className={`w-full px-4 py-2.5 rounded-xl border text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-brand-500/20 focus:border-brand-500 transition-all ${
                      isDarkMode 
                        ? 'bg-slate-950 border-slate-800 text-white' 
                        : 'bg-slate-50 border-slate-200 text-slate-950'
                    }`}
                  />
                </div>

                <div className="flex gap-3 justify-end pt-2">
                  <button
                    type="button"
                    onClick={() => setIsSettingsOpen(false)}
                    className={`px-4 py-2 text-xs font-bold rounded-xl border transition ${
                      isDarkMode 
                        ? 'border-slate-800 hover:bg-slate-800 text-slate-300' 
                        : 'border-slate-200 hover:bg-slate-100 text-slate-600'
                    }`}
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={settingsSaving || !settingsShopName.trim()}
                    className="px-5 py-2 text-xs font-bold text-white bg-brand-600 hover:bg-brand-700 rounded-xl shadow-md transition"
                  >
                    {settingsSaving ? 'Saving...' : 'Save Changes'}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
