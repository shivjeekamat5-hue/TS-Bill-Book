import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Store, Phone, MapPin, Tag, Coins } from 'lucide-react';
import { Shopkeeper } from '../types';

interface ShopkeeperFormProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: Omit<Shopkeeper, 'id' | 'createdAt'>) => Promise<void>;
  shopkeeper?: Shopkeeper | null; // For editing
  isDarkMode: boolean;
}

const CATEGORIES = [
  'Kirana Store',
  'Medical Store',
  'Vegetable Seller',
  'General Store',
  'Wholesale Dealer',
  'Hardware Store',
  'Garment Store',
  'Electrical Store',
  'Other Business'
];

export default function ShopkeeperForm({ isOpen, onClose, onSubmit, shopkeeper, isDarkMode }: ShopkeeperFormProps) {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [category, setCategory] = useState('Kirana Store');
  const [address, setAddress] = useState('');
  const [monthlyBillAmount, setMonthlyBillAmount] = useState<number | ''>('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (shopkeeper) {
      setName(shopkeeper.name);
      setPhone(shopkeeper.phone || '');
      setCategory(shopkeeper.category || 'Kirana Store');
      setAddress(shopkeeper.address || '');
      setMonthlyBillAmount(shopkeeper.monthlyBillAmount !== undefined ? shopkeeper.monthlyBillAmount : '');
    } else {
      // Clear fields for new shopkeeper
      setName('');
      setPhone('');
      setCategory('Kirana Store');
      setAddress('');
      setMonthlyBillAmount('');
    }
    setError('');
  }, [shopkeeper, isOpen]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Business / Customer name is required.');
      return;
    }
    setLoading(true);
    setError('');
    try {
      await onSubmit({
        name: name.trim(),
        phone: phone.trim(),
        category,
        address: address.trim(),
        monthlyBillAmount: monthlyBillAmount === '' ? undefined : Number(monthlyBillAmount)
      });
      onClose();
    } catch (err: any) {
      setError(err.message || 'Error saving shopkeeper.');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-slate-950/60 backdrop-blur-sm"
        />

        {/* Modal content */}
        <motion.div
          initial={{ scale: 0.95, y: 15, opacity: 0 }}
          animate={{ scale: 1, y: 0, opacity: 1 }}
          exit={{ scale: 0.95, y: 15, opacity: 0 }}
          className={`relative w-full max-w-md rounded-3xl shadow-2xl overflow-hidden border z-10 transition-all ${
            isDarkMode 
              ? 'bg-slate-900 border-slate-800 text-white' 
              : 'bg-white border-slate-100 text-slate-900'
          }`}
        >
          {/* Header */}
          <div className={`px-6 py-4 border-b flex justify-between items-center ${
            isDarkMode ? 'border-slate-800 bg-slate-900/50' : 'border-slate-100 bg-slate-50'
          }`}>
            <h3 className="font-extrabold text-lg flex items-center gap-2">
              <Store className="w-5 h-5 text-brand-500" />
              {shopkeeper ? 'Edit Shopkeeper' : 'Add Shopkeeper'}
            </h3>
            <button
              onClick={onClose}
              className="p-1.5 rounded-full hover:bg-slate-200 dark:hover:bg-slate-800 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="p-6 space-y-4">
            {error && (
              <div className="p-3 bg-red-500/10 border border-red-500/20 text-red-500 text-xs rounded-xl">
                {error}
              </div>
            )}

            <div>
              <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1.5">
                Business / Customer Name *
              </label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400">
                  <Store className="w-4 h-4" />
                </span>
                <input
                  type="text"
                  required
                  placeholder="e.g. Balaji Medicals"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className={`w-full pl-9 pr-4 py-2 rounded-xl border text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 focus:border-brand-500 transition-all ${
                    isDarkMode 
                      ? 'bg-slate-950 border-slate-800 text-white placeholder-slate-700' 
                      : 'bg-slate-50 border-slate-200 text-slate-900 placeholder-slate-400'
                  }`}
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1.5">
                Category
              </label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400">
                  <Tag className="w-4 h-4" />
                </span>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className={`w-full pl-9 pr-4 py-2 rounded-xl border text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 focus:border-brand-500 transition-all appearance-none cursor-pointer ${
                    isDarkMode 
                      ? 'bg-slate-950 border-slate-800 text-white' 
                      : 'bg-slate-50 border-slate-200 text-slate-900'
                  }`}
                >
                  {CATEGORIES.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
                <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none text-slate-400">
                  ▼
                </div>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1.5">
                Monthly Bill Amount (₹)
              </label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400">
                  <Coins className="w-4 h-4" />
                </span>
                <input
                  type="number"
                  min={0}
                  placeholder="e.g. 1500"
                  value={monthlyBillAmount}
                  onChange={(e) => setMonthlyBillAmount(e.target.value === '' ? '' : Number(e.target.value))}
                  className={`w-full pl-9 pr-4 py-2 rounded-xl border text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 focus:border-brand-500 transition-all ${
                    isDarkMode 
                      ? 'bg-slate-950 border-slate-800 text-white placeholder-slate-700' 
                      : 'bg-slate-50 border-slate-200 text-slate-900 placeholder-slate-400'
                  }`}
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1.5">
                Phone Number
              </label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400">
                  <Phone className="w-4 h-4" />
                </span>
                <input
                  type="tel"
                  placeholder="e.g. 9876543210"
                  maxLength={12}
                  value={phone}
                  onChange={(e) => setPhone(e.target.value.replace(/\D/g, ''))}
                  className={`w-full pl-9 pr-4 py-2 rounded-xl border text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 focus:border-brand-500 transition-all ${
                    isDarkMode 
                      ? 'bg-slate-950 border-slate-800 text-white placeholder-slate-700' 
                      : 'bg-slate-50 border-slate-200 text-slate-900 placeholder-slate-400'
                  }`}
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1.5">
                Address / Location
              </label>
              <div className="relative">
                <span className="absolute top-2.5 left-0 pl-3 flex items-start text-slate-400">
                  <MapPin className="w-4 h-4" />
                </span>
                <textarea
                  placeholder="e.g. Market Road, Block A"
                  rows={2}
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className={`w-full pl-9 pr-4 py-2 rounded-xl border text-sm focus:outline-none focus:ring-2 focus:ring-brand-500/40 focus:border-brand-500 transition-all ${
                    isDarkMode 
                      ? 'bg-slate-950 border-slate-800 text-white placeholder-slate-700' 
                      : 'bg-slate-50 border-slate-200 text-slate-900 placeholder-slate-400'
                  }`}
                />
              </div>
            </div>

            <div className="pt-4 flex gap-3 justify-end">
              <button
                type="button"
                onClick={onClose}
                className={`px-4 py-2 text-sm font-semibold rounded-xl border transition ${
                  isDarkMode 
                    ? 'border-slate-800 hover:bg-slate-800 text-slate-300' 
                    : 'border-slate-200 hover:bg-slate-100 text-slate-600'
                }`}
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={loading}
                className="px-5 py-2 text-sm font-semibold text-white bg-gradient-to-r from-brand-600 to-emerald-500 hover:from-brand-700 hover:to-emerald-600 rounded-xl shadow-md disabled:opacity-50 transition cursor-pointer"
              >
                {loading ? 'Saving...' : shopkeeper ? 'Save Changes' : 'Add Shopkeeper'}
              </button>
            </div>
          </form>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
