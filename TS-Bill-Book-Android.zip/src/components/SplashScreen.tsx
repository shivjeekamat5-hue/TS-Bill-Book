import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ReceiptText, CheckSquare, Sparkles } from 'lucide-react';

interface SplashScreenProps {
  onComplete: () => void;
}

export default function SplashScreen({ onComplete }: SplashScreenProps) {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(() => {
            onComplete();
          }, 400); // Small delay for final completeness feel
          return 100;
        }
        return prev + 4; // Fills up in about 2.5 seconds
      });
    }, 80);

    return () => clearInterval(interval);
  }, [onComplete]);

  return (
    <div id="splash-screen" className="fixed inset-0 bg-slate-900 flex flex-col items-center justify-center text-white z-50">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {/* Ambient background glow */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 left-1/2 -translate-x-1/2 translate-y-1/2 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl" />
      </div>

      <div className="relative flex flex-col items-center max-w-xs w-full px-6 text-center">
        {/* Animated Icon Container */}
        <motion.div
          initial={{ scale: 0.5, opacity: 0 }}
          animate={{ scale: [1, 1.05, 1], opacity: 1 }}
          transition={{ duration: 1.5, repeat: Infinity, ease: 'easeInOut' }}
          className="relative w-24 h-24 bg-gradient-to-tr from-emerald-500 to-teal-400 rounded-3xl flex items-center justify-center shadow-xl shadow-emerald-500/20 mb-6"
        >
          <ReceiptText className="w-12 h-12 text-white stroke-[2.2]" />
          
          <motion.div 
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.6, duration: 0.5, type: 'spring' }}
            className="absolute -top-1 -right-1 bg-yellow-400 p-1.5 rounded-full text-slate-900 shadow-md"
          >
            <Sparkles className="w-4 h-4 fill-yellow-400" />
          </motion.div>
        </motion.div>

        {/* Brand Text */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.8 }}
          className="mb-8"
        >
          <h1 className="text-3xl font-extrabold tracking-tight bg-gradient-to-r from-white via-slate-100 to-emerald-400 bg-clip-text text-transparent">
            TS Bill Book
          </h1>
          <p className="text-slate-400 text-xs mt-1 font-mono uppercase tracking-[0.2em]">
            Professional Billing Hub
          </p>
        </motion.div>

        {/* Loading Bar */}
        <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden mb-3">
          <motion.div 
            className="h-full bg-gradient-to-r from-emerald-500 to-cyan-400"
            style={{ width: `${progress}%` }}
          />
        </div>

        {/* Status Text */}
        <motion.span 
          key={progress}
          className="text-[10px] font-mono text-slate-400 uppercase tracking-widest"
        >
          {progress < 30 ? 'Initializing core...' : progress < 70 ? 'Loading databases...' : progress < 100 ? 'Securing backup...' : 'Ready'}
        </motion.span>
      </div>

      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 text-center">
        <p className="text-[10px] text-slate-500 font-mono">
          v1.0.0 • Offline Ready
        </p>
      </div>
    </div>
  );
}
