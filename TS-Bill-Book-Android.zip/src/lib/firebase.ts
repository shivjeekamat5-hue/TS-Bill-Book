/// <reference types="vite/client" />
import { initializeApp } from 'firebase/app';
import { 
  getAuth, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut, 
  sendPasswordResetEmail,
  signInWithCustomToken
} from 'firebase/auth';
import { 
  initializeFirestore, 
  persistentLocalCache, 
  persistentMultipleTabManager,
  collection,
  doc,
  setDoc,
  getDoc,
  getDocs,
  addDoc,
  updateDoc,
  deleteDoc,
  query,
  orderBy,
  where
} from 'firebase/firestore';
import { Shopkeeper, Bill, UserProfile } from '../types';
import firebaseConfigData from '../../firebase-applet-config.json';

const getEnvVal = (val: any, fallback: string, validator?: (v: string) => boolean): string => {
  if (typeof val !== 'string' || !val) return fallback;
  const trimmed = val.trim();
  const placeholders = [
    'apiKey', 'projectId', 'authDomain', 'storageBucket', 
    'messagingSenderId', 'appId', 'measurementId', 'firestoreDatabaseId'
  ];
  if (placeholders.includes(trimmed)) return fallback;
  if (validator && !validator(trimmed)) return fallback;
  return trimmed;
};

// Prioritize config file values first to completely eliminate stale env variables
const projectId = getEnvVal(firebaseConfigData.projectId || import.meta.env.VITE_FIREBASE_PROJECT_ID, "ts-bill-book");
const appId = getEnvVal(firebaseConfigData.appId || import.meta.env.VITE_FIREBASE_APP_ID, "1:786819318665:web:347ec237195d8f18801758", (v) => v.startsWith('1:'));
const apiKey = getEnvVal(firebaseConfigData.apiKey || import.meta.env.VITE_FIREBASE_API_KEY, "AIzaSyA8xrdXXXzovsjTPjfD1_WnxKmhcDaeq-I", (v) => v.startsWith('AIzaSy'));
const authDomain = getEnvVal(firebaseConfigData.authDomain || import.meta.env.VITE_FIREBASE_AUTH_DOMAIN, "ts-bill-book.firebaseapp.com", (v) => v.endsWith('.com'));
const storageBucket = getEnvVal(firebaseConfigData.storageBucket || import.meta.env.VITE_FIREBASE_STORAGE_BUCKET, "ts-bill-book.firebasestorage.app");
const messagingSenderId = getEnvVal(firebaseConfigData.messagingSenderId || import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID, "786819318665", (v) => /^\d+$/.test(v));
const firestoreDatabaseId = getEnvVal(firebaseConfigData.firestoreDatabaseId || import.meta.env.VITE_FIREBASE_FIRESTORE_DATABASE_ID, "ai-studio-tsbillbook-1c25e62c-25de-4f9a-8c26-057bae78d16d");
const measurementId = getEnvVal(firebaseConfigData.measurementId || import.meta.env.VITE_FIREBASE_MEASUREMENT_ID, "");

const firebaseConfig = {
  projectId,
  appId,
  apiKey,
  authDomain,
  firestoreDatabaseId: firestoreDatabaseId || undefined,
  storageBucket,
  messagingSenderId,
  measurementId
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Auth
export const auth = getAuth(app);

// Initialize Firestore with persistent multi-tab local caching (offline mode)
export const db = initializeFirestore(app, {
  localCache: persistentLocalCache({
    tabManager: persistentMultipleTabManager()
  })
}, firebaseConfig.firestoreDatabaseId);

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// User Profile Helpers
export async function saveUserProfile(userId: string, profile: Partial<UserProfile>) {
  if (userId === 'local-demo-user') {
    const existing = localStorage.getItem('tsbillbook_profile_local-demo-user');
    const parsed = existing ? JSON.parse(existing) : {};
    const updated = { ...parsed, ...profile, uid: userId };
    localStorage.setItem('tsbillbook_profile_local-demo-user', JSON.stringify(updated));
    return;
  }

  const path = `users/${userId}`;
  try {
    const cleanedProfile = { ...profile };
    const currentUser = auth.currentUser;
    if (currentUser) {
      const email = currentUser.email || '';
      cleanedProfile.role = email === 'shivjeekamat5@gmail.com' ? 'owner' : 'user';
    } else {
      delete cleanedProfile.role;
    }

    const userDoc = doc(db, 'users', userId);
    await setDoc(userDoc, cleanedProfile, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function getUserProfile(userId: string): Promise<UserProfile | null> {
  if (userId === 'local-demo-user') {
    const existing = localStorage.getItem('tsbillbook_profile_local-demo-user');
    if (existing) {
      return JSON.parse(existing) as UserProfile;
    }
    // Return a default profile for the guest demo
    return {
      uid: 'local-demo-user',
      email: 'demo@tsbillbook.com',
      displayName: 'Guest Shopkeeper',
      businessName: 'TS Demo Kirana Store',
      businessAddress: '123 Market Street, New Delhi',
      businessPhone: '9876543210',
      role: 'user'
    };
  }

  const path = `users/${userId}`;
  try {
    const userDoc = doc(db, 'users', userId);
    const snap = await getDoc(userDoc);
    const currentUser = auth.currentUser;

    if (snap.exists()) {
      const data = snap.data() as UserProfile;
      const targetRole = (data.email === 'shivjeekamat5@gmail.com' ? 'owner' : 'user') as 'owner' | 'user';
      if (data.role !== targetRole) {
        const updated = { ...data, role: targetRole };
        await setDoc(userDoc, { role: targetRole }, { merge: true });
        return updated;
      }
      return data;
    } else if (currentUser && currentUser.uid === userId) {
      const email = currentUser.email || '';
      const targetRole = (email === 'shivjeekamat5@gmail.com' ? 'owner' : 'user') as 'owner' | 'user';
      const defaultProfile: UserProfile = {
        uid: userId,
        email: email,
        displayName: email.split('@')[0],
        businessName: '',
        businessAddress: '',
        businessPhone: '',
        role: targetRole
      };
      await setDoc(userDoc, defaultProfile);
      return defaultProfile;
    }
    return null;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
    return null;
  }
}

// Shopkeeper / Customer CRUD Operations
export async function addShopkeeper(userId: string, shopkeeper: Omit<Shopkeeper, 'id' | 'createdAt'>): Promise<Shopkeeper> {
  const createdAt = new Date().toISOString();
  
  if (userId === 'local-demo-user') {
    const key = 'tsbillbook_shopkeepers_local-demo-user';
    const existing = localStorage.getItem(key);
    const shopkeepers: Shopkeeper[] = existing ? JSON.parse(existing) : [];
    const newShopkeeper: Shopkeeper = {
      id: `local-shop-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      ...shopkeeper,
      createdAt
    };
    shopkeepers.push(newShopkeeper);
    localStorage.setItem(key, JSON.stringify(shopkeepers));
    return newShopkeeper;
  }

  const path = `users/${userId}/shopkeepers`;
  try {
    const shopkeepersCol = collection(db, 'users', userId, 'shopkeepers');
    const docRef = await addDoc(shopkeepersCol, {
      ...shopkeeper,
      createdAt
    });
    return {
      id: docRef.id,
      ...shopkeeper,
      createdAt
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
    throw error;
  }
}

export async function updateShopkeeper(userId: string, shopkeeperId: string, shopkeeper: Partial<Shopkeeper>): Promise<void> {
  if (userId === 'local-demo-user') {
    const key = 'tsbillbook_shopkeepers_local-demo-user';
    const existing = localStorage.getItem(key);
    if (existing) {
      const shopkeepers: Shopkeeper[] = JSON.parse(existing);
      const updated = shopkeepers.map(s => s.id === shopkeeperId ? { ...s, ...shopkeeper } : s);
      localStorage.setItem(key, JSON.stringify(updated));
    }
    return;
  }

  const path = `users/${userId}/shopkeepers/${shopkeeperId}`;
  try {
    const docRef = doc(db, 'users', userId, 'shopkeepers', shopkeeperId);
    await updateDoc(docRef, shopkeeper);
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function deleteShopkeeper(userId: string, shopkeeperId: string): Promise<void> {
  if (userId === 'local-demo-user') {
    const key = 'tsbillbook_shopkeepers_local-demo-user';
    const existing = localStorage.getItem(key);
    if (existing) {
      const shopkeepers: Shopkeeper[] = JSON.parse(existing);
      const filtered = shopkeepers.filter(s => s.id !== shopkeeperId);
      localStorage.setItem(key, JSON.stringify(filtered));
    }
    return;
  }

  const path = `users/${userId}/shopkeepers/${shopkeeperId}`;
  try {
    const docRef = doc(db, 'users', userId, 'shopkeepers', shopkeeperId);
    await deleteDoc(docRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export async function getShopkeepers(userId: string): Promise<Shopkeeper[]> {
  if (userId === 'local-demo-user') {
    const key = 'tsbillbook_shopkeepers_local-demo-user';
    const existing = localStorage.getItem(key);
    if (existing) {
      const list = JSON.parse(existing) as Shopkeeper[];
      return list.sort((a, b) => a.name.localeCompare(b.name));
    }
    // Seed default sample shopkeepers for demo
    const defaultShopkeepers: Shopkeeper[] = [
      {
        id: 'demo-shopkeeper-1',
        name: 'Sharma General Store',
        phone: '9876543211',
        category: 'General Store',
        address: 'Sec-5, Noida, UP',
        balance: 1500,
        createdAt: new Date().toISOString()
      },
      {
        id: 'demo-shopkeeper-2',
        name: 'Gupta Sweets & Bakers',
        phone: '9876543212',
        category: 'Kirana Store',
        address: 'Connaught Place, New Delhi',
        balance: -450,
        createdAt: new Date().toISOString()
      },
      {
        id: 'demo-shopkeeper-3',
        name: 'Karan Provisions',
        phone: '9876543213',
        category: 'Kirana Store',
        address: 'Chandni Chowk, Delhi',
        balance: 0,
        createdAt: new Date().toISOString()
      }
    ];
    localStorage.setItem(key, JSON.stringify(defaultShopkeepers));
    return defaultShopkeepers;
  }

  const path = `users/${userId}/shopkeepers`;
  try {
    const shopkeepersCol = collection(db, 'users', userId, 'shopkeepers');
    const q = query(shopkeepersCol, orderBy('name', 'asc'));
    const snap = await getDocs(q);
    return snap.docs.map(d => ({
      id: d.id,
      ...d.data()
    })) as Shopkeeper[];
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
    return [];
  }
}

// Billing Operations
export async function saveBill(userId: string, bill: Omit<Bill, 'id' | 'createdAt'>): Promise<Bill> {
  const createdAt = new Date().toISOString();

  if (userId === 'local-demo-user') {
    const key = 'tsbillbook_bills_local-demo-user';
    const existing = localStorage.getItem(key);
    const bills: Bill[] = existing ? JSON.parse(existing) : [];
    const newBill: Bill = {
      id: `local-bill-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      ...bill,
      createdAt
    };
    bills.push(newBill);
    localStorage.setItem(key, JSON.stringify(bills));
    
    // Also update shopkeeper balance locally!
    const skKey = 'tsbillbook_shopkeepers_local-demo-user';
    const skExisting = localStorage.getItem(skKey);
    if (skExisting) {
      const shopkeepers: Shopkeeper[] = JSON.parse(skExisting);
      const updated = shopkeepers.map(s => {
        if (s.id === bill.shopkeeperId) {
          const change = bill.grandTotal;
          return { ...s, balance: (s.balance || 0) + change };
        }
        return s;
      });
      localStorage.setItem(skKey, JSON.stringify(updated));
    }

    return newBill;
  }

  const path = `users/${userId}/bills`;
  try {
    const billsCol = collection(db, 'users', userId, 'bills');
    const docRef = await addDoc(billsCol, {
      ...bill,
      createdAt
    });
    return {
      id: docRef.id,
      ...bill,
      createdAt
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
    throw error;
  }
}

export async function updateBill(userId: string, billId: string, bill: Partial<Bill>): Promise<void> {
  if (userId === 'local-demo-user') {
    const key = 'tsbillbook_bills_local-demo-user';
    const existing = localStorage.getItem(key);
    if (existing) {
      const bills: Bill[] = JSON.parse(existing);
      const updated = bills.map(b => b.id === billId ? { ...b, ...bill } : b);
      localStorage.setItem(key, JSON.stringify(updated));
    }
    return;
  }

  const path = `users/${userId}/bills/${billId}`;
  try {
    const docRef = doc(db, 'users', userId, 'bills', billId);
    await updateDoc(docRef, bill);
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function deleteBill(userId: string, billId: string): Promise<void> {
  if (userId === 'local-demo-user') {
    const key = 'tsbillbook_bills_local-demo-user';
    const existing = localStorage.getItem(key);
    if (existing) {
      const bills: Bill[] = JSON.parse(existing);
      const billToDelete = bills.find(b => b.id === billId);
      const filtered = bills.filter(b => b.id !== billId);
      localStorage.setItem(key, JSON.stringify(filtered));

      // Reverse shopkeeper balance adjustment
      if (billToDelete) {
        const skKey = 'tsbillbook_shopkeepers_local-demo-user';
        const skExisting = localStorage.getItem(skKey);
        if (skExisting) {
          const shopkeepers: Shopkeeper[] = JSON.parse(skExisting);
          const updated = shopkeepers.map(s => {
            if (s.id === billToDelete.shopkeeperId) {
              const change = -billToDelete.grandTotal;
              return { ...s, balance: (s.balance || 0) + change };
            }
            return s;
          });
          localStorage.setItem(skKey, JSON.stringify(updated));
        }
      }
    }
    return;
  }

  const path = `users/${userId}/bills/${billId}`;
  try {
    const docRef = doc(db, 'users', userId, 'bills', billId);
    await deleteDoc(docRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export async function getBills(userId: string): Promise<Bill[]> {
  if (userId === 'local-demo-user') {
    const key = 'tsbillbook_bills_local-demo-user';
    const existing = localStorage.getItem(key);
    if (existing) {
      const list = JSON.parse(existing) as Bill[];
      return list.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    }
    // Seed default sample bills for demo
    const defaultBills: Bill[] = [
      {
        id: 'demo-bill-1',
        shopkeeperId: 'demo-shopkeeper-1',
        shopkeeperName: 'Sharma General Store',
        date: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        items: [
          { id: '1', name: 'Refined Oil 5L', price: 650, quantity: 2, pieces: 'pcs', total: 1300 },
          { id: '2', name: 'Basmati Rice 10kg', price: 200, quantity: 1, pieces: 'pcs', total: 200 }
        ],
        grandTotal: 1500,
        notes: 'Delivery completed. Outstanding payment due.',
        paymentStatus: 'unpaid',
        createdAt: new Date().toISOString()
      },
      {
        id: 'demo-bill-2',
        shopkeeperId: 'demo-shopkeeper-2',
        shopkeeperName: 'Gupta Sweets & Bakers',
        date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        items: [
          { id: '1', name: 'Sugar 50kg bag', price: 2250, quantity: 1, pieces: 'box', total: 2250 }
        ],
        grandTotal: 2250,
        notes: 'Paid fully in cash upon delivery.',
        paymentStatus: 'paid',
        paymentDate: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        createdAt: new Date().toISOString()
      },
      {
        id: 'demo-bill-3',
        shopkeeperId: 'demo-shopkeeper-2',
        shopkeeperName: 'Gupta Sweets & Bakers',
        date: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        items: [],
        grandTotal: 450,
        notes: 'Customer advanced cash deposit.',
        paymentStatus: 'partial',
        paymentDate: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        createdAt: new Date().toISOString()
      }
    ];
    localStorage.setItem(key, JSON.stringify(defaultBills));
    return defaultBills;
  }

  const path = `users/${userId}/bills`;
  try {
    const billsCol = collection(db, 'users', userId, 'bills');
    const q = query(billsCol, orderBy('date', 'desc'), orderBy('createdAt', 'desc'));
    const snap = await getDocs(q);
    return snap.docs.map(d => ({
      id: d.id,
      ...d.data()
    })) as Bill[];
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
    return [];
  }
}

export async function getShopkeeperBills(userId: string, shopkeeperId: string): Promise<Bill[]> {
  if (userId === 'local-demo-user') {
    const all = await getBills(userId);
    return all.filter(b => b.shopkeeperId === shopkeeperId);
  }

  const path = `users/${userId}/bills`;
  try {
    const billsCol = collection(db, 'users', userId, 'bills');
    const q = query(
      billsCol, 
      where('shopkeeperId', '==', shopkeeperId),
      orderBy('date', 'desc')
    );
    const snap = await getDocs(q);
    return snap.docs.map(d => ({
      id: d.id,
      ...d.data()
    })) as Bill[];
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
    return [];
  }
}

export async function getAllUsers(): Promise<UserProfile[]> {
  const path = 'users';
  try {
    const usersCol = collection(db, 'users');
    const snap = await getDocs(usersCol);
    return snap.docs.map(d => ({
      uid: d.id,
      ...d.data()
    })) as UserProfile[];
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
    return [];
  }
}
