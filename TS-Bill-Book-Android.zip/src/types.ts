export interface Shopkeeper {
  id: string;
  name: string;
  phone: string;
  category: string;
  address: string;
  balance?: number;
  monthlyBillAmount?: number;
  createdAt: string;
}

export interface BillItem {
  id: string;
  name: string;
  quantity: number;
  pieces: string; // e.g., 'pcs', 'kg', 'ltr', 'box', 'packet', 'dozen'
  price: number;
  total: number;
}

export interface Bill {
  id: string;
  shopkeeperId: string;
  shopkeeperName: string;
  date: string; // YYYY-MM-DD
  items: BillItem[];
  grandTotal: number;
  createdAt: string;
  notes?: string;
  paymentStatus?: 'paid' | 'unpaid' | 'partial';
  paymentDate?: string; // YYYY-MM-DD
}

export interface UserProfile {
  uid: string;
  email: string;
  displayName?: string;
  phoneNumber?: string;
  businessName?: string;
  businessAddress?: string;
  businessPhone?: string;
  role?: 'owner' | 'user';
}
